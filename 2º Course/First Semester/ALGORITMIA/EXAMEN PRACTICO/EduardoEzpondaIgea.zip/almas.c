#include <stdio.h>
#include <stdbool.h>

#include "colaDoble.h"
tipoCuenta entregarAres (tipoColaDoble *cola);

int main(){
	
	tipoColaDoble cola;
    tipoElemento elem;
    tipoCuenta cuenta, cuenta2;
    int numOfrendas;
	char opcion;
	
	nuevaColaDoble(&cola);
	do
    {
		printf("Introduce clase de espiritu griego (a para ateniense, e para espartano, en otro caso termina la guerra): ");
		scanf(" %c",&opcion);
		if (opcion == 'a')
		{          
			printf("Introduce numero de ofrendas del espiritu griego: ");
            scanf("%d",&numOfrendas);
            elem.id = opcion;
            elem.cantidad = numOfrendas;
            encolar(&cola, elem);
        }    
				   
		else if (opcion == 'e')
		{
            printf("Introduce numero de ofrendas del espiritu griego: ");
            scanf("%d",&numOfrendas);
            elem.id = opcion;
            elem.cantidad = numOfrendas;
            encolar(&cola, elem);
		}
        else if (opcion == 'f')
        {
			cuenta = eliminarAparicionesRetornarSuma(&cola, 'a');
			printf("Se han entregado a Atenea %d almas atenienses sumando un total de %d ofrendas\n",cuenta.contador,cuenta.cantidad);
			cuenta2 = entregarAres(&cola);
			printf("Se han entregado a Ares %d almas espartanas sumando un total de %d ofrendas\n",cuenta2.contador,cuenta2.cantidad);
		}
		else
		{
			
		}
				
   
	}while(opcion == 'a' || opcion == 'e');
}
tipoCuenta entregarAres (tipoColaDoble *cola)
{
	tipoCuenta cuenta;
	tipoElemento x,y;
	int ofrendasUlt;
	bool salir;
	
	cuenta.contador = 0;
	cuenta.cantidad = 0;
	
	if (esNulaColaDoble(*cola))
	{
		
	}
	else
	{
		if (cuenta.contador == 0)
		{
			x = elemPrimero(*cola);
			y = elemUltimo(*cola);
			
			if (x.cantidad < y.cantidad)
			{
				desencolarPrimero(cola);
				cuenta.contador = cuenta.contador + 1;
				cuenta.cantidad = cuenta.cantidad + x.cantidad;
				ofrendasUlt = x.cantidad;
			}
			else
			{
				desencolarUltimo(cola);
				cuenta.contador = cuenta.contador + 1;
				cuenta.cantidad = cuenta.cantidad + y.cantidad;
				ofrendasUlt = y.cantidad;
			}
		}
		else
		{
			salir = false;
			
			while (!esNulaColaDoble(*cola) && salir == false)
			{
				x = elemPrimero(*cola);
				y = elemUltimo(*cola);
				
				if (x.cantidad >= ofrendasUlt && y.cantidad >= ofrendasUlt)
				{
					if (x.cantidad < y.cantidad)
					{
						desencolarPrimero(cola);
						cuenta.contador = cuenta.contador + 1;
						cuenta.cantidad = cuenta.cantidad + x.cantidad;
						ofrendasUlt = x.cantidad;
					}
					else 
					{
						desencolarUltimo(cola);
						cuenta.contador = cuenta.contador + 1;
						cuenta.cantidad = cuenta.cantidad + y.cantidad;
						ofrendasUlt = y.cantidad;
					}
				}
				else if (x.cantidad >= ofrendasUlt && y.cantidad < ofrendasUlt)
				{
					desencolarPrimero(cola);
					cuenta.contador = cuenta.contador + 1;
					cuenta.cantidad = cuenta.cantidad + x.cantidad;
					ofrendasUlt = x.cantidad;
				}
				else if (x.cantidad < ofrendasUlt && y.cantidad >= ofrendasUlt)
				{
					desencolarUltimo(cola);
					cuenta.contador = cuenta.contador + 1;
					cuenta.cantidad = cuenta.cantidad + y.cantidad;
					ofrendasUlt = y.cantidad;
				}
				else
				{
					salir = true;
				}
				
			}
		}
	}
	
	return cuenta;
}

