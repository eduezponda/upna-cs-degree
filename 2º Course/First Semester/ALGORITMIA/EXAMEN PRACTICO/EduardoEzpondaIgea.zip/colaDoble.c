#include <stdio.h>
#include <stdlib.h>
#include "colaDoble.h"



void nuevaColaDoble(tipoColaDoble *c)
{
    c->ini = NULL;
    c->fin = NULL;
}

bool esNulaColaDoble(tipoColaDoble c)
{
    return c.ini == NULL || c.fin == NULL;
}

void encolar(tipoColaDoble* c, tipoElemento elem)
{
    celdaColaDoble *aux;
    
    aux = malloc(sizeof(celdaColaDoble));
    aux->sig = NULL;
    aux->elemento = elem;
    
    if (!esNulaColaDoble(*c))
    {
        c->fin->sig = aux;
        aux->ant = c->fin;
        c->fin = aux;
    }
    else
    {
        aux->ant = NULL;
        c->ini = aux;
        c->fin = aux;
    }
}

void desencolarPrimero(tipoColaDoble * c)
{
    celdaColaDoble *aux;
    
    if (esNulaColaDoble(*c))
    {
        printf("No se puede desencolar de una cola nula\n");
    }
    else
    {
        aux = c->ini;
        c->ini = c->ini->sig;
        if (esNulaColaDoble(*c))
        {
            c->fin = NULL;
        }
        else
        {
             c->ini->ant = NULL;
        }
        free(aux);
    }
}

void desencolarUltimo(tipoColaDoble * c)
{
    celdaColaDoble *aux;
    
    if (esNulaColaDoble(*c))
    {
        printf("No se puede desencolar de una cola nula\n");
    }
    else
    {
        aux = c->fin;
        c->fin = c->fin->ant;
        if (esNulaColaDoble(*c))
        {
            c->ini = NULL;
        }
        else
        {
            c->fin->sig = NULL;
        }
        free(aux);
    }
}

tipoElemento elemPrimero(tipoColaDoble c)
{
    if (!esNulaColaDoble(c))
    {
        return c.ini->elemento;
    }
    else
    {
        printf("No se puede mostrar un elemento de una cola nula\n");
        
    }
}

tipoElemento elemUltimo(tipoColaDoble c)
{
    if (!esNulaColaDoble(c))
    {
        return c.fin->elemento;
    }
    else
    {
        printf("No se puede mostrar un elemento de una cola nula\n");
        
    }
}

tipoCuenta eliminarAparicionesRetornarSuma(tipoColaDoble* c , char a)
{
    celdaColaDoble *aux, *aux2;
    tipoCuenta cuenta;
    
    cuenta.contador = 0;
    cuenta.cantidad = 0;
    
    if(esNulaColaDoble(*c))
    {
        
    }
    else
    {
        aux = c->ini;
        
        while (aux != NULL)
        {
            if (aux->elemento.id == a)
            {
                if (aux == c->ini && aux != c->fin)
                {
                    aux2 = aux;
                    aux->sig->ant = NULL;
                    c->ini = c->ini->sig;
                }
                else if (aux == c->fin && aux != c->ini)
                {
                    aux2 = aux;
                    aux->ant->sig = NULL;
                    c->fin = c->fin->ant;
                }
                else if (aux == c->fin && aux == c->ini)
                {
                    aux2 = aux;
                    c->ini = NULL;
                    c->fin = NULL;
                }
                else
                {
                    aux2 = aux;
                    aux->ant->sig = aux->sig;
                    aux->sig->ant = aux->ant;
                }
                cuenta.contador = cuenta.contador + 1;
                cuenta.cantidad = cuenta.cantidad + aux2->elemento.cantidad;
                free(aux2);
            }
            aux = aux->sig;
            
        }
    }
    return cuenta;
}

