#include <stdbool.h>

typedef struct tipoCuenta{
	int contador;
	int cantidad;
}tipoCuenta;

typedef struct tipoElemento{
	char id;
	int cantidad;
}tipoElemento;

typedef struct celdaColaDoble{
	tipoElemento elemento;
	struct celdaColaDoble* ant;
	struct celdaColaDoble* sig;
} celdaColaDoble; 

typedef struct tipoColaDoble{
	celdaColaDoble* ini;
	celdaColaDoble* fin;
}tipoColaDoble;

void nuevaColaDoble(tipoColaDoble *);

bool esNulaColaDoble(tipoColaDoble);

void encolar(tipoColaDoble*, tipoElemento);

void desencolarPrimero(tipoColaDoble *);

void desencolarUltimo(tipoColaDoble *);

tipoElemento elemPrimero(tipoColaDoble);

tipoElemento elemUltimo(tipoColaDoble);

tipoCuenta eliminarAparicionesRetornarSuma(tipoColaDoble* , char);
