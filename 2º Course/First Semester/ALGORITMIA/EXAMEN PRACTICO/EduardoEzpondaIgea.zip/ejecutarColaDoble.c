#include<stdio.h>

#include "colaDoble.h"

int main(){
	tipoElemento elemento;
	tipoCuenta cuenta;
	tipoColaDoble cola;
	int opcion;
	char id;
	
	nuevaColaDoble(&cola);
	do
    {
		printf("--------MENU-------- \n");
		printf("1 - Encolar un elemento\n");
		printf("2 - Desencolar un elemento del inicio\n");
		printf("3 - Desencolar un elemento del final\n");
		printf("4 - Mostrar el elemento del inicio.\n");
		printf("5 - Mostrar el elemento del final.\n");
                printf("6 - Eliminar apariciones de un elemento y mostrar su suma acumulada.\n");
		printf("7 - Salir.\n");
		printf("Escoja una opcion: ");
		scanf("%d",&opcion);
		switch(opcion){           
			case 1: 
				printf("Introduce id del elemento: ");
				scanf(" %c",&elemento.id);
				printf("Introduce cantidad del elemento: ");
				scanf("%d",&elemento.cantidad);
				encolar(&cola, elemento);
				break;   
			case 2: 
				desencolarPrimero(&cola);
				printf("Se ha eliminado el primer elemento\n");
				break;
			case 3: 
				desencolarUltimo(&cola);
				printf("Se ha eliminado el ultimo elemento\n");
				break;
			case 4:
				elemento=elemPrimero(cola);
				printf("El primer elemento es %c con cantidad %d\n", elemento.id, elemento.cantidad);
				break;
			case 5:
				elemento=elemUltimo(cola);
				printf("El ultimo elemento es %c con cantidad %d\n", elemento.id, elemento.cantidad);
				break;
			case 6:
				printf("Introduce id del elemento: ");
				scanf(" %c",&id);
				cuenta=eliminarAparicionesRetornarSuma(&cola, id);
				printf("Se han eliminado %d apariciones del elemento %c que sumaban %d\n", cuenta.contador, id, cuenta.cantidad);
				break;
		}
	}while(opcion<7);
}
