#! /bin/bash
make
./bmp_imagen
display test.bmp &
