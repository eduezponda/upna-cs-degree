#! /bin/bash
make clean
make
./bmp_imagen
display test_as.bmp &
