import java.io.*;
public class Casino{
    public static void main(String[] args) throws IOException{
        Partida p1 = new Partida();
        p1.partida();
    }
}
