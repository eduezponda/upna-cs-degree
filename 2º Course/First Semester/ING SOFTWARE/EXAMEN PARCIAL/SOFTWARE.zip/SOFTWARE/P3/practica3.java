import java.lang.*;
import java.io*;
import java.util.Scanner;

class Dado //Lanzarlo y ver el resultado
{
    public void 
    {
        int dado1 = (int)(Math.ramdom()*6+1);
        System.out.println("El resultado del primer dado es: ");    
        int dado2 = (int)(Math.ramdom()*6+1);
        System.out.println("El resultado del segundo dado es: ");
    }
}

class Partida //Array de turnos
{

}

class Turno //Pensar
{

}

class Casino //Main
{
    
}
