package correduria;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author alumno
 */
public interface IVistaAdmision {

    String consultarNombre();
    String consultarApellido();
    Integer consultarAnnoNacimiento();
    Integer consultarSalarioAnual();
    String consultarTipoBien();
    Integer consultarValorBien();
    
}
