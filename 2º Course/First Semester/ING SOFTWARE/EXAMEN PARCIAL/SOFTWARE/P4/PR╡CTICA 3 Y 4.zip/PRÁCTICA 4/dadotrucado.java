//Guillermo Azcona Recari
//PRÁCTICA 4 Casino
//13/10/2021

import java.lang.*;
import java.io.*;
import java.util.Scanner;

class DadoTrucado extends Dado
{

    public void lanzar()
    {
        numeroDado = 1;
    }
    
}
