/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package casinoPOO;

/**
 *
 * @author alumno
 */
public class Casino {
    private Jugador jugador1;
    private Jugador jugador2;
    private Partida partida;
    
    public Casino (String j1, String j2)
    {
        jugador1 = new Jugador(j1);
        jugador2 = new Jugador(j2);
        partida = new Partida (jugador1,jugador2);
    }
    public void jugarTurnos(){
        
        System.out.println("Comienza la partida");
        int i = 0;
        while (i < 5 && !partida.partidaFinalizada()){
            
            System.out.println(" Turno " + String.valueOf(i+1));
            partida.jugarTurno();
            
            if (partida.partidaFinalizada())
            {
                if(jugador1.obtenerOjosDeTigre()){
                 System.out.println(" Ha ganado la partida: " + jugador1.obtenerNombre()); 
                 
                }
                else
                {
                    System.out.println("Ha ganado la partida: " +jugador2.obtenerNombre());
                }
            }
            else
            {
                 if(jugador1.obtenerPuntuacion() > jugador2.obtenerPuntuacion()){
                    System.out.println(" Ha ganado el turno: " + jugador1.obtenerNombre());
                    jugador1.sumarTurno();
                 } else if(jugador1.obtenerPuntuacion() < jugador2.obtenerPuntuacion()){
                    System.out.println(" Ha ganado el turno: " + jugador2.obtenerNombre()); 
                    jugador2.sumarTurno();
                }
                else{
                    System.out.println(" Empate!"); 
                }
            }
            i = i + 1;
         
        } 
        
        if(!partida.partidaFinalizada()){
            if(jugador1.obtenerTurnos() > jugador2.obtenerTurnos()){
                 System.out.println(" Ha ganado la partida: " + jugador1.obtenerNombre()); 
            }
            else if(jugador1.obtenerTurnos() < jugador2.obtenerTurnos()){
                 System.out.println(" Ha ganado la partida: " + jugador2.obtenerNombre()); 
            }
            else{
                 System.out.println(" Partida empatada"); 
            } 
        }
    }
}
