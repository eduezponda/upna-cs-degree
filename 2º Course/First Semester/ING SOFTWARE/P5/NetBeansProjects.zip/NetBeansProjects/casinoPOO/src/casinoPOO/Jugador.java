/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package casinoPOO;


/**
 *
 * @author alumno
 */
public class Jugador {
    private  String nombre;
    private  int puntuacion;
    private  boolean esOjosDeTigre;
    private  int numeroTurnosGanados;
    
    public Jugador (String nnombre)
    {
        nombre = nnombre;
        puntuacion = 0;
        esOjosDeTigre = false;
        numeroTurnosGanados = 0;
    }
    public String obtenerNombre()
    {
        return nombre;
    }
    public int obtenerPuntuacion()
    {
        return puntuacion;
    }
    public void sumarPuntuacion(int puntos)
    {
       
        puntuacion = puntuacion + puntos;
    }
    public void sumarTurno ()
    {
        numeroTurnosGanados = numeroTurnosGanados + 1;
    }
    public void reiniciarJugador()
    {
        puntuacion = 0;
        esOjosDeTigre = false;
    }
    public void esOjosDeTigre (boolean b)
    {
        esOjosDeTigre = b;
    }
    public boolean obtenerOjosDeTigre ()
    {
        return esOjosDeTigre;
    }
    public int obtenerTurnos ()
    {
        return numeroTurnosGanados;
    }
    
  
}
