/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package casinoPOO;


// JUGADOR A

/**
 *
 * @author alumno
 */
public class Partida {
    
    private Jugador jugador1;
    private Jugador jugador2;
    private boolean finPartida;
    private Dado dado1;
    private Dado dado2;
    
    public Partida (Jugador j1, Jugador j2)
    {
        jugador1 = j1;
        jugador2 = j2;
        finPartida = false;
        dado1 = new Dado();
        dado2 = new Dado();
    }
    
 
    
    public void jugarTurno(){
        
        jugador1.reiniciarJugador();
        
        System.out.println("  Juega " + jugador1.obtenerNombre()); 
        System.out.println("    Primer dado es " + String.valueOf(dado1.tirarDado()));
        System.out.println("    Segundo dado es " + String.valueOf(dado2.tirarDado()));
        jugador1.sumarPuntuacion (dado1.obtenerResultado());
        jugador1.sumarPuntuacion (dado2.obtenerResultado());
        
        jugador1.esOjosDeTigre(dado1.obtenerResultado() == 1 && dado2.obtenerResultado() == 1);
        if(jugador1.obtenerOjosDeTigre()) { 
            
                System.out.println("    Enhorabuena, Ojos de Tigre!");
        }
        System.out.println("  Total: " + String.valueOf(jugador1.obtenerPuntuacion()));
        
        jugador2.reiniciarJugador();
        
        System.out.println("  Juega " + jugador2.obtenerNombre()); 
        System.out.println("    Primer dado es " + String.valueOf(dado1.tirarDado()));
        System.out.println("    Segundo dado es " + String.valueOf(dado2.tirarDado()));
        jugador2.sumarPuntuacion (dado1.obtenerResultado());
        jugador2.sumarPuntuacion (dado2.obtenerResultado());
        
        jugador2.esOjosDeTigre(dado1.obtenerResultado() == 1 && dado2.obtenerResultado() == 1);
        if(jugador2.obtenerOjosDeTigre()) { 
            
                System.out.println("    Enhorabuena, Ojos de Tigre!");
        }
        System.out.println("  Total: " + String.valueOf(jugador2.obtenerPuntuacion()));
        
        if ((jugador1.obtenerOjosDeTigre() && !jugador2.obtenerOjosDeTigre()) || (!jugador1.obtenerOjosDeTigre() && jugador2.obtenerOjosDeTigre())) {
            finPartida = true;
        }
    }
    
    public boolean partidaFinalizada ()
    {
        return finPartida;
    }
    
}
       
    
       
    


        
    
    
    

