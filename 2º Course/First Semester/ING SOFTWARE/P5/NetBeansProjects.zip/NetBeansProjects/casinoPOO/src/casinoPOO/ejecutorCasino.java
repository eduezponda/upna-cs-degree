/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package casinoPOO;

import java.util.Scanner;

/**
 *
 * @author alumno
 */
public class ejecutorCasino {
    
     private static final Scanner scan = new Scanner(System.in);
     
     public static void  main (String[] args){
        
         System.out.print("Introduce el nombre de jugador 1: ");
         String j1 = scan.next();
         System.out.print("Introduce el nombre de jugador 2: ");
         String j2 = scan.next();
         
         Casino casino = new Casino (j1,j2);
         casino.jugarTurnos();
    }
}
    

