package Soluciones;

public class Ejercicio2 {
    
    public static Boolean esPar(int n){ //nombre métodos en minúscula
       
        return n % 2 == 0;
    }
    
    public static void main(String[] args) {
        // paso 1. Cambia el nombre del método para mostrar que devuelve una variable booleana
        // paso 2. El metodo estatico puede escribirse en una sola linea.
        System.out.println(esPar(2));
        System.out.println(esPar(3));
    }
    
}
