package Soluciones;

public class Ejercicio4 {
    private String[] diasSemana = {"lunes","martes","miercoles","jueves","viernes","sabado","domingo"};
    public String diaSemana(int dia){
        switch (dia)
        {
            
            case 1:
                return diasSemana[0]; //dia-1
            case 2:
                return diasSemana[1];
            case 3:
                return diasSemana[2];
            case 4:
                return diasSemana[3];
            case 5:
                return diasSemana[4];
            case 6:
                return diasSemana[5];
            case 7:
                return diasSemana[6];
            default:
                return "dia incorrecto";
        }
    }

    public static void main(String[] args) {
        Ejercicio4 ejercicio4 = new Ejercicio4();
        System.out.println(ejercicio4.diaSemana(3));
    }
    
}
//se podria poner la string y la funcion con static, para luego no hacer el new, ni poner ejercicio4.diaSemana(3)

// paso 1. Modifica la firma del método para hacerlo más semantico (nombre función)
// paso 2. Sustituye los ifs anidados por "case" de un "switch"
// paso 3. Escribe los dias de la semana en un array de String de forma ordenada, usa el parametro de entrada
// del método como indice del array para buscar el día de la semana.