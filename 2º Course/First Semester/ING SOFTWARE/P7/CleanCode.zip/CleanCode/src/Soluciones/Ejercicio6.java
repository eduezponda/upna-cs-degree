package Soluciones;

public class Ejercicio6 {
    
    public static String letraDNI(int d){
        DNI dni = new DNI();
        return dni.devolverLetra(d%23);
    }


    public static void main(String[] args) {
        System.out.println(letraDNI(72700123)); 
    }
    
}


// paso 1. Crea una clase "Dni". Añade un método público para validar la letra de control.
// paso 2. Sustituye el switch por un array de chars
// paso 3. Sustituye el array de char por un string. Pedes hacer uso de charAt para seleccionar un determinado caracter del string