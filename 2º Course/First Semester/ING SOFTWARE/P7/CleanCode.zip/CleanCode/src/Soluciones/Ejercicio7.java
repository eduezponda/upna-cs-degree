package Soluciones;

public class Ejercicio7 {

    public static void main(String[] args) {
        // Crea una clase "Paciente" que encapsule en atributos el nombre, el año de nacimiento, el peso y la altura.
        // Añade métodos privados para calcular la edad y el IMC
        // Añade un método publico para saber si tiene riesgo cardiovascular o no.
        // Modifica el método estatico para recibir un array de Pacientes. Mejora el nombre del método.
    }
    
}
