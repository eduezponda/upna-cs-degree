#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/sem.h>



void manejador(); //manejador de las señales
void tiempoPasa();
void actuarSemaforo(int id, int num, struct sembuf *a, int accion);


//variables globales para poder ser liberadas tras la señal ctrl+c
struct sembuf accion; //struct para actuar sobre semaforos
int numLicencias;
int id_sem; //Identificadores de las distintas estructuras utilizadas en el sistema


int main (int argc, char** argv) { //recoge la clave

    signal(SIGINT, manejador); //control de señales
    
    if (argc < 5) { //comprueba si se ha introducido la clave
        printf("Clave y/o numero de licencias y/o nombre FIFO y/o periodo no introducidos\n");
        exit(-1);
    }
    

    key_t clave = atoi(argv[1]); //recojo la clave introducida


    if (clave == (key_t) -1) { //compruebo si es valida
        printf("Clave erronea\n");
        exit(-2);
    }
    
    if ((id_sem = semget(clave, 2, 0660)) == -1) { //creo el array de semaforos y compruebo error
        printf("Error al crear los semaforos\n");
        exit(-3);
    }
    
    srand((unsigned int) time(NULL)); //activo la semilla de la funcion rand() para su utilizacion dentro de tiempoPasa()
    
    int fifo = open(argv[3], O_WRONLY);
    
    close(STDOUT_FILENO);
    dup2(fifo, STDOUT_FILENO);
    
    numLicencias = atoi(argv[2]);

    accion.sem_flg = 0; //inicializo la flag para posteriores cambios en los semaforos
    
    actuarSemaforo(id_sem, 1, &accion, - numLicencias);
    
    actuarSemaforo(id_sem, 0, &accion, -1);
    
    printf("Concedidas %d licencias al proceso %d.\n", numLicencias, getpid());
    
    tiempoPasa();
    
    actuarSemaforo(id_sem, 0, &accion, 1);
    
    for(int i = 0; i < atoi(argv[4]); i ++) {
        tiempoPasa();
    }
    
    actuarSemaforo(id_sem, 1, &accion, numLicencias);
    
    actuarSemaforo(id_sem, 0, &accion, -1);
    
    printf("Liberadas las %d licencias previamente concedidas al proceso %d.\n", numLicencias, getpid());
    
    actuarSemaforo(id_sem, 0, &accion, 1);
}


void manejador() { //maneja las señales redirigidas por signal()

    actuarSemaforo(id_sem, 1, &accion, numLicencias);
    
    actuarSemaforo(id_sem, 0, &accion, -1);
    
    printf("Liberadas las %d licencias previamente concedidas al proceso %d.\n", numLicencias, getpid());
    
    actuarSemaforo(id_sem, 0, &accion, 1);
    
    exit(1); //Termina la ejecucion del proceso en cuestion
}

void actuarSemaforo(int id, int num, struct sembuf *a, int accion) { //realiza el cambio de valor del semaforo al igual que la espera si es necesario

    if (accion != 0) { //comprueba que "se necesiten algo del material" para que no haya error
        a->sem_num = num; //numero de semaforo
        a->sem_op = accion; //accion que se quiere realizar (wait/signal)
        semop(id, a, 1); //se llama a la accion que cambia el valor
    }
}

void tiempoPasa() { //simula el paso del tiempo (1s)
    unsigned int i;
    int a = 5;

    for (i = rand() / 10; i > 0; i --) {
        a = a % 5 + i;
    }
}
