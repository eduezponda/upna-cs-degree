#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <stdbool.h>
#include <string.h>



void manejador(); //manejador de las señales


//variables globales para poder ser liberadas tras la señal ctrl+c
bool aFichero;
char fich[25];
FILE *f;
int i;


int main (int argc, char** argv) { //recoge la clave

    signal(SIGINT, manejador); //control de señales
    
    aFichero = false;
    i = 0;
    
    if (argc > 1) {
        
        strcpy(fich, argv[1]);

        if ((f = fopen(fich, "w")) == NULL) { //abro el fichero y compruebo error
            printf("Error en el nombre del fichero. Recuerde que debe existir y que debe estar en el mismo directorio\n");
            exit (-4);
        }
        aFichero = true; //se usa fichero
    }

    
    char mensaje[100];
    
    
    while(1) {
        
        while (scanf("%[^\n]", mensaje) < 1) {
            fgetc(stdin);
        }
        fgetc(stdin);
        
        if (aFichero) {
            fputs(mensaje, f);
            fputc('\n', f);
        }
        else {
            printf("%s\n", mensaje);
        }
        i ++;
    }
}


void manejador() { //maneja las señales redirigidas por signal()
    
    if (aFichero) {
        printf("\nRegistradas %d peticiones en el fichero %s\n", i / 2, fich);
        
        fclose(f);
    }
    else {
        printf("\nRegistradas %d peticiones en pantalla\n", i / 2);
    }
    
    exit(1); //Termina la ejecucion del proceso en cuestion
}
