#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>
#include <sys/ipc.h>
#include <sys/types.h> 
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/sem.h>
#include <string.h>



void manejador(int s); //manejador de las señales


//variables globales para poder ser liberadas tras la señal ctrl+c
int id_sem; //Identificadores de las distintas estructuras utilizadas en el sistema
char nombreFIFO[25];


int main (int argc, char** argv) { //recoge la clave

    signal(SIGUSR1, manejador); //control de señales
    signal(SIGINT, manejador); //control de señales
    
    if (argc < 4) { //comprueba si se ha introducido la clave
        printf("Clave y/o numero de licencias y/o nombre FIFO no introducidos\n");
        exit(-1);
    }
    

    key_t clave = atoi(argv[1]); //recojo la clave introducida


    if (clave == (key_t) -1) { //compruebo si es valida
        printf("Clave erronea\n");
        exit(-2);
    }

    if ((id_sem = semget(clave, 2, 0660 | IPC_CREAT)) == -1) { //creo el array de semaforos y compruebo error
        printf("Error al crear los semaforos\n");
        exit(-3);
    }
    
    
    int fifo;
    
    
    strcpy(nombreFIFO, argv[3]);
    
    
    if ((fifo = mkfifo(nombreFIFO, O_RDWR | O_CREAT | 0660)) == -1) {
        printf("Error al crear la FIFO\n");
        
        raise(SIGUSR1);
    }
    
    
    fifo = open(nombreFIFO, O_RDWR);


    struct sembuf accion; //struct para actuar sobre semaforos


    accion.sem_flg = 0; //inicializo la flag para posteriores cambios en los semaforos

    
    semctl(id_sem, 0, SETVAL, 1); //valor inicial para simular que esta en verde (semaforo de FIFO)
    semctl(id_sem, 1, SETVAL, atoi(argv[2])); //valor inicial para simular que hay "numLicencias" licencias

    srand((unsigned int) time(NULL)); //activo la semilla de la funcion rand() para su utilizacion dentro de tiempoPasa()
    
    int pid = fork();
    
    if (pid == 0)
    {
        char ** log;
        
        close (STDIN_FILENO);
        dup2(fifo, STDIN_FILENO);
        
        if (argc > 4) {
            log = (char **)malloc(sizeof(char *) * 3);
            log[0] = (char *)malloc(sizeof(char) * 9);
            strcpy(log[0], "./logger");
            log[1] = (char *)malloc(sizeof(char) * strlen(argv[4]) + 1);
            strcpy(log[1], argv[4]);
            log[2] = NULL;
            execvp(log[0], log);
        }
        else {
            log = (char **)malloc(sizeof(char *) * 2);
            log[0] = (char *)malloc(sizeof(char) * 9);
            strcpy(log[0], "./logger");
            log[1] = NULL;
            execvp(log[0], log);
        }
    }

    while (1) { //bucle hasta la señal Ctrl+C
        
    }
}


void manejador(int s) { //maneja las señales redirigidas por signal()

    printf("\nTerminando proceso servidor...\n");
    
    if (s == SIGUSR1) {
        if (semctl(id_sem, 0, IPC_RMID) == -1) { //borra la memoria compartida y comprueba error
            printf("\nError borrando semaforos\n");

            exit(-5);
        }
    }
    else {
        remove(nombreFIFO);
        if (semctl(id_sem, 0, IPC_RMID) == -1) { //borra la memoria compartida y comprueba error
            printf("\nError borrando semaforos\n");

            exit(-5);
        }
    }

    exit(1); //Termina la ejecucion del proceso en cuestion
}
