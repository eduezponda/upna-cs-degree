#include <string.h>
#include <stdlib.h>

char **fragmenta(char *cadena);
void borrar(char ** cadena);
