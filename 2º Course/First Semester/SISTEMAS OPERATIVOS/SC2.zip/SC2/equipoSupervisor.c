#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h> 
#include <sys/stat.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/msg.h>
#include <sys/wait.h>
#include <signal.h>
#include <string.h>
#include "prueba.c"
#include "indicador.c"

int shmid, semid, msgid, pid, fp;
struct indicador * memoria;
int main(int argc, char ** argv)
{
    int i;
    int tuberia[2];
    char LOG[23];
    sprintf (LOG, "ES_%d.txt", atoi(argv[1]));
    fp = open(LOG, O_RDWR | O_CREAT, 0660);
    shmid = shmget(atoi(argv[3])-atoi(argv[1]), sizeof(indicador), S_IRUSR | S_IWUSR);
    memoria = (struct indicador *)shmat(shmid, NULL, 0);
    semid = semget(atoi(argv[3])-atoi(argv[1]), 1, 0);
    msgid = msgget(atoi(argv[3]), S_IRUSR | S_IWUSR);
    pipe(tuberia);
    for (i=0; i<atoi(argv[2]); i++)
    {
        pid = fork();
        if (pid == 0)
        {
            dup2 (tuberia[1], STDOUT_FILENO);
            char ** prob;
            prob = (char **)malloc(sizeof(char *)*6);
            prob[0] = (char *)malloc(sizeof(char)*16);
            strcpy(prob[0], "./pruebaCalidad");
            prob[1] = (char *)malloc(sizeof(char)*7);
            strcpy(prob[1], argv[3]);
            prob[2] = (char *)malloc(sizeof(char)*3);
            sprintf (prob[2], "%d", i);
            prob[3] = (char *)malloc(sizeof(char)*3);
            strcpy(prob[3], argv[1]);
            prob[4] = (char *)malloc(sizeof(char)*3);
            strcpy(prob[4], argv[4]);
            prob[5] = NULL;
            execvp(prob[0], prob);
        }
    }
    struct prueba p;
    char text[100];
    struct sembuf act;
    act.sem_num = 0;
    act.sem_flg = 0;
    struct indicador ind;
    while(1)
    {
        read(tuberia[0], &p, sizeof(prueba));
        sprintf (text, "Prueba %d del probador %d sobre la mercancía %ld del equipo supervisor %d con resultado %s\n", p.numeroPrueba, p.probadorId, p.idMercancia, atoi(argv[1]), p.resulPrueba?"OK":"NOK");
        write(fp, text, strlen(text));
        act.sem_op = -1;
        semop(semid, &act, 1);
        ind = *memoria;
        if (p.resulPrueba == 1)
            ind.OK ++;
        else
            ind.NOK ++;
        ind.pruebas ++;
        *memoria = ind;
        act.sem_op = 1;
        semop(semid, &act, 1);
    }
}
void onCtrlC(int a)
{
    shmdt(memoria);
    close(fp);
}
