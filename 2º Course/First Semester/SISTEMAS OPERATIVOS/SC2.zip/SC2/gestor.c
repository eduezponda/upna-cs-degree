#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h> 
#include <sys/stat.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/msg.h>
#include <sys/wait.h>
#include <signal.h>
#include <string.h>
#include "mensaje.c"
#include "indicador.c"

void onCtrlC(int);

int shmid, semid, pid;
int * msgid;
union semun
{
    int val;
    struct semid_ds *buf;
    ushort *array;
};
int main(int argc, char ** argv)
{
    int i, fifo;
    struct indicador * memoria;
    signal(SIGINT, onCtrlC);
    msgid = (int *)malloc(sizeof(int)*(atoi(argv[3])+1));
    shmid = shmget(atoi(argv[1]), sizeof(indicador), IPC_CREAT | IPC_EXCL | S_IRUSR | S_IWUSR);
    if (shmid == -1)
    {
        printf ("Error al crear la memoria comaprtida.\n");
        exit(0);
    }
    struct indicador ind;
    ind.OK = 0;
    ind.NOK = 0;
    ind.pruebas = 0;
    memoria = (struct indicador *)shmat(shmid, NULL, 0);
    *memoria = ind;
    semid = semget(atoi(argv[1]), 1, IPC_CREAT | IPC_EXCL | S_IRUSR | S_IWUSR);
    if (semid == -1)
    {
        printf ("Error al crear el semaforo.\n");
        exit(0);
    }
    union semun arg;
    arg.val = 1;
    semctl( semid, 0, SETVAL, arg);
    fifo = mkfifo("fifo.txt", O_RDWR | O_CREAT | 0660);
    if (fifo == -1)
    {
        printf ("Error al crear el fifo.\n");
        exit(0);
    }
    fifo = open("fifo.txt", O_RDWR);
    for (i=0; i<atoi(argv[2]); i++)
    {
        pid = fork();
        if (pid == 0)
        {
            char ** merc; 
            merc = (char **)malloc(sizeof(char *)*3);
            merc[0] = (char *)malloc(sizeof(char)*12);
            strcpy(merc[0], "./mercancia");
            merc[1] = (char *)malloc(sizeof(char)*3);
            strcpy(merc[1], argv[5]);
            merc[2] = NULL;
            execvp(merc[0], merc);
        }
    }
    for (i=0; i<atoi(argv[3]); i++)
    {
        pid = fork();
        if (pid == 0)
        {
            char ** super;
            super = (char **)malloc(sizeof(char *)*6);
            super[0] = (char *)malloc(sizeof(char)*19);
            strcpy(super[0], "./equipoSupervisor");
            super[1] = (char *)malloc(sizeof(char)*3);
            sprintf (super[1], "%d", i);
            super[2] = (char *)malloc(sizeof(char)*3);
            strcpy(super[2], argv[4]);
            super[3] = (char *)malloc(sizeof(char)*7);
            sprintf (super[3], "%d", atoi(argv[1])+i);
            super[4] = (char *)malloc(sizeof(char)*3);
            strcpy(super[4], argv[6]);
            super[5] = NULL;
            execvp(super[0], super);
        }
        msgid[i] = msgget(atoi(argv[1])+i, IPC_CREAT | IPC_EXCL | S_IRUSR | S_IWUSR);
    }
    msgid[i] = -1;
    i = 0;
    struct mensaje m;
    while(1)
    {
        read(fifo, &m, sizeof(struct mensaje));
        msgsnd(msgid[i], &m, sizeof(struct mensaje)-sizeof(long), 0);
        i++;
        if (i == atoi(argv[3]))
            i = 0;
    }
}
void onCtrlC(int a)
{
    kill(-pid, SIGINT);
    wait(NULL);
    shmctl(shmid, IPC_RMID, NULL);
    semctl(semid, 0, IPC_RMID);
    remove("fifo.txt");
    int i = 0;
    while (msgid[i] != -1)
    {
        msgctl(msgid[i], IPC_RMID, 0);
        i++;
    }
    exit(0);
}
