struct indicador
{
    int OK;
    int NOK;
    int pruebas;
} indicador;
