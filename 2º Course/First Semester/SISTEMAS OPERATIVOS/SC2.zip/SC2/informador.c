#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <signal.h>
#include <sys/shm.h>
#include <fcntl.h>
#include "indicador.c"

void onCtrlC (int);
struct indicador *memoria;

int main(int argc, char ** argv)
{
    signal (SIGINT, onCtrlC);
    int shmid;
    shmid = shmget(atoi(argv[1]), sizeof(indicador), S_IRUSR | S_IWUSR);
    memoria = (struct indicador *)shmat(shmid, NULL, 0);
    char tiempo[128];
    time_t tmp = time(0);
    struct tm *tlocal = localtime(&tmp);
    struct indicador ind;
    while (1)
    {
        tmp = time(0);
        tlocal = localtime(&tmp);
        ind = *memoria;
        strftime(tiempo, 128, "%d/%m/%y %H:%M:%S", tlocal);
        
        printf ("%s informador %d control de calidad.\n", tiempo, getpid());
        printf ("OK: %d  NOK: %d  Totales: %d\n", ind.OK, ind.NOK, ind.pruebas);
        sleep(atoi(argv[2]));
    }
}

void onCtrlC(int i)
{
    shmdt(memoria);
    exit(0);
}
