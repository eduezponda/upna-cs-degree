#include <time.h>
struct mensaje
{
    long idMercancia;
    struct tm * instante;
} mensaje;
