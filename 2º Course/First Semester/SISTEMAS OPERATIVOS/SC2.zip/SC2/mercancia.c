#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h> 
#include <sys/stat.h>
#include "mensaje.c"

int main(int argc, char ** argv)
{
    sleep(atoi(argv[1]));
    int fifo;
    time_t tiempo = time(0);
    struct mensaje m;
    m.idMercancia = getpid();
    m.instante = localtime(&tiempo);
    fifo = open("fifo.txt", O_RDWR);
    if (fifo == -1)
    {
        printf ("Error al crear el fifo.\n");
        exit(0);
    }
    write(fifo, &m, sizeof(mensaje));
}
