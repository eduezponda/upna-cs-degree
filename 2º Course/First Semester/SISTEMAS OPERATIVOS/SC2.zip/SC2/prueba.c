struct prueba
{
    long idMercancia;
    int resulPrueba;
    int numeroPrueba;
    int probadorId;
}prueba;
