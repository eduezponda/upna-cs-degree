#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <sys/msg.h>
#include <fcntl.h>
#include <unistd.h>
#include "prueba.c"
#include "mensaje.c"

int main(int argc, char ** argv)
{
    int i, msgid;
    char text[101];
    double num;
    struct prueba pru;
    struct mensaje m;
    srand((unsigned)time(NULL));
    msgid = msgget(atoi(argv[1]), S_IRUSR | S_IWUSR);
    i = 1;
    while(1)
    {
        sleep(atoi(argv[4]));
        msgrcv (msgid, &m, sizeof(struct mensaje)-sizeof(long), 0, 0);
        pru.idMercancia = m.idMercancia;
        num = (double) rand()/RAND_MAX;
        if (num < 0.5)
            pru.resulPrueba = 0;
        else
            pru.resulPrueba = 1;
        pru.probadorId = atoi(argv[2]);
        pru.numeroPrueba = i;
        write (STDOUT_FILENO, &pru, sizeof(struct prueba));
        if (i % 5 == 0)
        {
            sprintf (text, "Probador %d descansando tras %d pruebas realizadas.\n", atoi(argv[2]), i);
            write(STDERR_FILENO, text, strlen(text)+1);
            sleep(3);
        }
        i++;
    }
}
