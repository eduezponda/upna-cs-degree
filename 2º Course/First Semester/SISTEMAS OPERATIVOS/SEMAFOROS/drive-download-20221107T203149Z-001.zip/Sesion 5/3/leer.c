//Programa: leer.
//Autor: Javier Aranguren Ortiz.
//Fecha: 25/10/2020.
/*Descripcion:  Este programa que permite acceder a la memoria compartida identificada
por el argumento clave y obtenga el valor del i-ésimo entero representado por
posicion y lo imprima por pantalla.*/

//Constantes
#define N 50 //Tamaño de la memoria (en enteros).

//Librerias
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>

void main(int argc, char **argv)
{
    //Variables
    int clave, posicion, valor, memoria, semaforo;
    struct sembuf ctrlSem;
    int *direccionMemoria;

    //Cuerpo
    printf("Programa: leer.\n");
    printf("Autor: Javier Aranguren Ortiz.\n");
    printf("Fecha: 25/10/2020.\n");
    printf("Descripcion: Este programa que permite acceder a la memoria compartida identificada por el argumento clave y obtenga el valor del i-ésimo entero representado por posicion y lo imprima por pantalla.\n");

    //Compruebo si el numero de argumentos introducidos es correcto
    if (argc != 3)
    {
        printf("\nEl numero de argumentos introducido es incorrecto, se deben introducir dos argumentos, el primero indica la clave y el segundo la posiciona a leer.\n");
        printf("ERROR 1\n\n");
        exit(1);
    }

    //Inicializo las variables
    clave = atoi(argv[1]);//atoi convierte un string en un entero
    posicion = atoi(argv[2]);

    //Creo la key
    if(-1 == (clave = ftok("fichero.txt", clave)))
    {
        printf("\nLa clave no se ha creado correctamente, seguramente porque no existe 'fichero.txt' en la misma carpeta que este programa, por favor cree el fichero.\n");
        printf("ERROR 2\n\n");
        exit(2);
    }

    //Accedo a la memoria
    if(-1 == (memoria = shmget(clave, sizeof(int)*N, 0777)))
    {
        printf("\nNo se ha podido acceder a la memoria correctamente, probablemente porque no existe\n");
        printf("ERROR 3\n\n");
        exit(3);
    }

    //Accedo al semaforo
    if (-1 == (semaforo = semget(clave, 1, 0777)))
    {
        printf("\nNo se ha podido acceder al semaforo correctamente\n");
        printf("ERROR 4\n\n");
        exit(4);
    }

    //El proceso entra en el semaforo
    ctrlSem.sem_num = 0;
    ctrlSem.sem_op = -1;
    ctrlSem.sem_flg = 0;
    if(-1 == semop(semaforo, &ctrlSem, 1))
    {
        printf("\nEl proceso tiene problemas con el semaforo");
        printf("ERROR 5\n\n");
        exit(5);
    }

    //Consulto el valor introducido
    direccionMemoria = (int*)shmat(memoria, NULL, 0);
    valor = *(direccionMemoria + sizeof(int) * posicion);
    shmdt(direccionMemoria);   //Libero la direccion de memoria

    //El proceso sale del semaforo
    ctrlSem.sem_op = 1;
    if(-1 == semop(semaforo, &ctrlSem, 1))
    {
        printf("\nEl proceso tiene problemas con el semaforo");
        printf("ERROR 6\n\n");
        exit(6);
    }

    printf("El valor es %d\n", valor);
    printf("Fin del programa, recuerde que este progrma no elimina la memoria compartida ni el semaforo, de ello se encarga el programa escribir.\n");
}