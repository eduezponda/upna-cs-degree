//Programa: inicializar.
//Autor: Javier Aranguren Ortiz.
//Fecha: 25/10/2020.
/*Descripcion:  Este programa crea una memoria compartida que contiene el valor indicado en todas sus posiciones.*/
/*Argumentos: inicializar
    clave: Identificador de la memoria compartida.
    valor: Numero con el que se quiere inicializar la memoria compartida.
    tamaño: Tamaño de la memoria compartida en enteros.
*/

//Librerias
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>

void main(int argc, char **argv)
{
    //Variables
    int clave, valor, tamano, memoria, semaforo;
    struct sembuf ctrlSem;
    int *direccionMemoria;

    //Cuerpo
    printf("Programa: inicializar.\n");
    printf("Autor: Javier Aranguren Ortiz.\n");
    printf("Fecha: 25/10/2020.\n");
    printf("Descripcion: Este programa crea una memoria compartida que contiene el valor indicado en todas sus posiciones.\n");
    printf("Argumentos: inicializar\n\tclave: Identificador de la memoria compartida.\n\tvalor: Numero con el que se quiere inicializar la memoria compartida.\n\ttamaño: Tamaño de la memoria compartida en enteros.\n");

    //Compruebo si el numero de argumentos introducidos es correcto
    if (argc != 4)
    {
        printf("\nEl numero de argumentos introducido es incorrecto, se deben introducir tres argumentos, el primero indica la clave, el segundo el valor con el que se quiere inicializar y el tercero el tamaño de la memoria en enteros.\n");
        printf("ERROR 1\n\n");
        exit(1);
    }

    //Inicializo las variables
    clave = atoi(argv[1]);//atoi convierte un string en un entero
    valor = atoi(argv[2]);
    tamano = atoi(argv[3]);

    //Creo la key
    if(-1 == (clave = ftok("fichero.txt", clave)))
    {
        printf("\nLa clave no se ha creado correctamente, seguramente porque no existe 'fichero.txt' en la misma carpeta que este programa, por favor cree el fichero.\n");
        printf("ERROR 2\n\n");
        exit(2);
    }

    //Creo la memoria compartida
    if(-1 == (memoria = shmget(clave, sizeof(int)*tamano, IPC_CREAT|0777)))
    {
        printf("\nLa memoria no se ha creado correctamente\n");
        printf("ERROR 3\n\n");
        exit(3);
    }

    //Creo el semaforo
    if (-1 == (semaforo = semget(clave, 1, IPC_CREAT|0777)))
    {
        printf("\nEl semaforo no se ha creado correctamente\n");
        printf("ERROR 4\n\n");
        exit(4);
    }

    //Inicializo el semaforo
    if (-1 == (semctl(semaforo, 0, SETVAL, 1)))
    {
        printf("\nEl semaforo no se ha inicializado correctamente\n");
        printf("ERROR 5\n\n");
        exit(5);
    }

    //El proceso entra en el semaforo
    ctrlSem.sem_num = 0;
    ctrlSem.sem_op = -1;
    ctrlSem.sem_flg = 0;
    if(-1 == semop(semaforo, &ctrlSem, 1))
    {
        printf("\nEl proceso tiene problemas con el semaforo");
        printf("ERROR 6\n\n");
        exit(6);
    }

    //Modifico el valor
    direccionMemoria = (int*)shmat(memoria, NULL, 0); //Obtengo la direccion de la memoria
    for (int posicion = 0; posicion < tamano; posicion++)
    {
        *(direccionMemoria + sizeof(int) * posicion) = valor;
    }
    shmdt(direccionMemoria);   //Libero la direccion de memoria

    //El proceso sale del semaforo
    ctrlSem.sem_op = 1;
    if(-1 == semop(semaforo, &ctrlSem, 1))
    {
        printf("\nEl proceso tiene problemas con el semaforo");
        printf("ERROR 7\n\n");
        exit(7);
    }

    //Espero para poder consultar en el otro programa
    printf("Introduzca cualquier caracter para eliminar el semaforo y la memoria compartida: ");
    scanf(" ");

    //Eliminamos el semaforo y la memoria
    if(-1 == semctl(semaforo, 0, IPC_RMID))
    {
        printf("\nEl semaforo no se ha eliminado correctamente\n");
        printf("ERROR 8\n\n");
        exit(8);
    }
    if(-1 == shmctl(memoria, IPC_RMID, 0))
    {
        printf("\nLa memoria no se ha eliminado correctamente\n");
        printf("ERROR 9\n\n");
        exit(9);
    }
    printf("Fin del programa\n");
}