//Programa: productor.
//Autor: Javier Aranguren Ortiz.
//Fecha: 25/10/2020.
/*Descripcion:  Este programa mete 10 mensajes en una cola cada periodo segundos.*/
/*Argumentos: inicializar
    clave_cola: Identificador de la cola.
    periodo: Cada cuanto tiempo se envia un mensaje.
*/

//Librerias
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>

//Constantes
#define N 10

//Estructuras

struct msgbuf {
 long mtype;
 int mensajeId;
}; 

void main(int argc, char **argv)
{
    //Variables
    int clave_cola, periodo;
    struct msgbuf msgBuffer;

    //Cuerpo
    printf("Programa: productor.\n");
    printf("Autor: Javier Aranguren Ortiz.\n");
    printf("Fecha: 25/10/2020.\n");
    printf("Descripcion:  Este programa mete 10 mensajes en una cola cada periodo segundos.\n");
    printf("Argumentos: inicializar\n\tclave_cola: Identificador de la cola.\n\tperiodo: Cada cuanto tiempo se envia un mensaje.\n");

    //Compruebo si el numero de argumentos introducidos es correcto
    if (argc != 3)
    {
        printf("\nEl numero de argumentos introducido es incorrecto, se deben introducir dos argumentos: 'clave_cola' y 'periodo'.\n");
        printf("ERROR 1\n\n");
        exit(1);
    }

    //Inicializo las variables
    clave_cola = atoi(argv[1]);//atoi convierte un string en un entero
    periodo = atoi(argv[2]);
    
    //Creo la key
    if(-1 == (clave_cola = ftok("fichero.txt", clave_cola)))
    {
        printf("\nLa clave no se ha creado correctamente, seguramente porque no existe 'fichero.txt' en la misma carpeta que este programa, por favor cree el fichero.\n");
        printf("ERROR 2\n\n");
        exit(2);
    }

    //Creo la cola
    if(-1 == (clave_cola = msgget (clave_cola, 0600 | IPC_CREAT)))
    {
        printf("\nLa cola no se ha creado correctamente.\n");
        printf("ERROR 3\n\n");
        exit(3);
    }

    //Meto mensajes en cola
    msgBuffer.mtype = 2;
    printf("\nEnviando mensajes:\n");
    for (int i = 1; i <= N; i++)
    {
        msgBuffer.mensajeId = i;
        msgsnd (clave_cola, &msgBuffer, sizeof(struct msgbuf)-sizeof(long), IPC_NOWAIT);
        printf("Enviado mensaje %d\n", i);
        sleep(periodo);
    }
    printf("Se han enviado todos los mensajes.\n\n");
}