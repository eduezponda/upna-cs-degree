void borrarg(char **arg);
char **fragmenta(const char *cadena);




