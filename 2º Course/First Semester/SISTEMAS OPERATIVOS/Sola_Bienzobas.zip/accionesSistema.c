/*
 * Program: accionesSistema.c
 * Version: 1.0
 * Date: 30/11/2022
 * Name: Fermin Sola
 */

#include "accionesSistema.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <signal.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <sys/ipc.h>
#include <time.h>
#include <sys/msg.h>
#include <stdbool.h>
#include <sys/sem.h>
#include <sys/shm.h>

key_t creacionClave(char *arg1, char *arg2){
	key_t clave;
	if((clave = ftok(arg1, atoi(arg2))) == -1){
		printf("\nERROR: Creacion clave\n");
		exit(1);
	}
	return(clave);
}

int creacionMemoriaCompartida(key_t clave){
	int memoria;
	if((memoria = shmget(clave, sizeof(int)*N, IPC_CREAT | 0777)) == -1){
		printf("\nERROR: Creacion memoria compartida\n");
		exit(1);
	}
	printf("Memoria compartida: %d\n", memoria);
	return(memoria);
}

int accesoMemoriaCompartida(key_t clave){
	int memoria;
	if((memoria = shmget(clave, sizeof(int)*N, 0777)) == -1){
		printf("\nERROR: Acceso memoria compartida\n");
		exit(1);
	}
	printf("Memoria compartida: %d\n", memoria);
	return(memoria);
}

int* obtenerDireccionMemoriaCompartida(int memoria){
	int *direccion;
	if((direccion = shmat(memoria, NULL, 0)) == (int *) -1){
		printf("\nERROR: Direccion de memoria compartida\n");
		exit(1);
	}
	return(direccion);
}

int creacionSemaforos(key_t clave, int i){
	int semaforo;
	semaforo = semget(clave, i, IPC_CREAT | 0777);
	if(semaforo == -1){
		printf("\nERROR: Creacion semaforo\n");
		exit(1);
	}
	printf("Semaforo: %d\n", semaforo);
	return(semaforo);
}

int accesoSemaforos(key_t clave, int i){
	int semaforo;
	semaforo = semget(clave, i, 0777);
	if(semaforo == -1){
		printf("\nERROR: Acceso semaforo\n");
		exit(1);
	}
	printf("Semaforo: %d\n", semaforo);
	return(semaforo);
}

int creacionColaMS(key_t clave){
	int idColaMS;
	if ((idColaMS = msgget(clave, IPC_CREAT | 0777)) == -1){
		perror("ERROR: Creacion cola de mensajes\n");
		exit(1);
	}
	printf("idColaMS: %d\n", idColaMS);
	return(idColaMS);
}

int accesoColaMS(key_t clave){
	int idColaMS;
	if ((idColaMS = msgget(clave, 0777)) == -1){
		perror("ERROR: Acceso cola de mensajes\n");
		exit(1);
	}
	printf("idColaMS: %d\n", idColaMS);
	return(idColaMS);
}

void inicializarSemaforo (int semaforo, int i, int valor){// no se si va con asterisco o no
	if(semctl(semaforo, i, SETVAL, valor) == -1){// entiendo que las posiciones de los semaforos van de 0 a i-1
		printf("\nERROR: Inicializar semaforo\n");
		exit(1);
	}
}

void accionSemaforo(struct sembuf *control, int semaforo, int pos, int valor){
	control->sem_num = pos;
	control->sem_op = valor;// suma este valor al sem_op --> sem_op = sem_op + valor
	if(semop(semaforo, &(*control), 1) == -1){
		printf("\nERROR: Operaciones semaforo %d\n", pos);
		exit(1);
	}
}

void eliminaMemoriaCompartida(int memoria){
	if(shmctl(memoria, IPC_RMID, 0) == -1){
		printf("\nERROR: Liberacion memoria compartida\n");
		exit(1);
	}	
}

void eliminaSemaforos(int semaforo, int i){
	if(semctl(semaforo, i, IPC_RMID) == -1){
		printf("\nERROR: Eliminacion semaforo 0\n");
		exit(1);
	}
}

void eliminaColaMS(int idColaMS){
	if(msgctl(idColaMS, IPC_RMID, 0) == -1){
		printf("\nERROR: Liberacion cola\n");
		exit(1);
	}
}
