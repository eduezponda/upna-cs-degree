/*
 * Program: accionesSistema.h
 * Version: 1.0
 * Date: 30/11/2022
 * Name: Fermin Sola
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <signal.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <sys/ipc.h>
#include <time.h>
#include <sys/msg.h>
#include <stdbool.h>
#include <sys/sem.h>
#include <sys/shm.h>

#define N 5		// para el tamaño de la memoria compartida
#define bloqueo -1
#define desbloqueo 1
#define semLicencias 0
#define semPeticiones 1

//https://www.chuidiang.org/clinux/ipcs/semaforo.php

typedef struct ordenProduccion {
	long tipoMensaje;
	int a;
	int b;
	int c;
}ordenProduccion;

struct msgbuf{
	long mtype;
	ordenProduccion ord;
};

key_t creacionClave(char *arg1, char *arg2);
int creacionMemoriaCompartida(key_t clave);
int accesoMemoriaCompartida(key_t clave);
int* obtenerDireccionMemoriaCompartida(int memoria);
int creacionSemaforos(key_t clave, int i);
int accesoSemaforos(key_t clave, int i);
int creacionColaMS(key_t clave);
int accesoColaMS(key_t clave);
void inicializarSemaforo (int semaforo, int i, int valor);
void accionSemaforo(struct sembuf *control, int semaforo, int pos, int valor);
void eliminaMemoriaCompartida(int memoria);
void eliminaSemaforos(int semaforo, int i);
void eliminaColaMS(int idColaMS);
