/*
 * Program: cliente
 * Version: 1.0
 * Date: 20/12/2022
 * Name: Fermin Sola
 */

#include "accionesSistema.h"

// ./cliente clave numLicencias nombreFifo periodo --> ./cliente /etc 10 5 miFifo 4

struct sembuf ctr;
int numLicencias, semaforo;
FILE *fifo;
char nombreFifo[20];

void manejador();

int main(int argc, char **argv){
	key_t clave;
	int periodo = atoi(argv[5]);
	strcpy(nombreFifo, argv[4]);
	numLicencias = atoi(argv[3]);
	
	if(argc != 6){
		printf("ERROR: Introduce los datos correctamente\n");
		exit(1);
	}
	clave = creacionClave(argv[1], argv[2]);
	semaforo = accesoSemaforos(clave, 2);
	
	signal(SIGINT, manejador);
	
	accionSemaforo(&ctr, semaforo, semLicencias, -numLicencias);
	
	accionSemaforo(&ctr, semaforo, semPeticiones, bloqueo);
	if((fifo = fopen(nombreFifo, "w")) == NULL){
		printf("ERROR: Apertura de la fifo\n");
		exit(1);
	}
	fprintf(fifo, "Concedidas las %d licencias al proceso %d\n", numLicencias, getpid());
	fclose(fifo);
	sleep(1);
	accionSemaforo(&ctr, semaforo, semPeticiones, desbloqueo);
	
	sleep(periodo);
	
	manejador();
	
	return 0;
}

void manejador(){
	accionSemaforo(&ctr, semaforo, semLicencias, numLicencias);
	
	accionSemaforo(&ctr, semaforo, semPeticiones, bloqueo);
	if((fifo = fopen(nombreFifo, "w")) == NULL){
		printf("ERROR: Apertura de la fifo\n");
		exit(1);
	}
	fprintf(fifo, "Liberadas las %d licencias previamente concedidas al proceso %d\n", numLicencias, getpid());
	fclose(fifo);
	sleep(1);
	accionSemaforo(&ctr, semaforo, semPeticiones, desbloqueo);
	printf("\n");
	raise(SIGKILL);
}
