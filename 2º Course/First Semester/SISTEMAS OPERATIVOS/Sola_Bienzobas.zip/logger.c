/*
 * Program: logger
 * Version: 1.0
 * Date: 20/12/2022
 * Name: Fermin Sola
 */

#include "accionesSistema.h"

// ./logger ficheroDeLog.txt

bool b = false;
char nombreFichero[20];
int peticiones = 0, fichero;

void manejador();

int main(int argc, char **argv){
	if((argc != 1) && (argc != 2)){
		printf("ERROR: Introduce los datos correctamente\n");
		exit(1);
	}
	
	if(argc == 2){
		b = true;
		strcpy(nombreFichero, argv[1]);
		fichero = open(nombreFichero, O_WRONLY|O_TRUNC|O_CREAT,S_IRUSR|S_IWUSR);
		dup2(fichero, STDOUT_FILENO);
	}
	
	signal(SIGINT, manejador);
	
	int msgRecibidos = 1;
	
	char msgFifo[100], msgAnterior[100];
	while(1){
		read(STDIN_FILENO, msgFifo, sizeof(msgFifo));
		//fread(msgFifo, sizeof(msgFifo), 1, STDIN_FILENO);
		if(msgFifo[0] == 'C'){ // he leido peticion
			peticiones++;
		}
		if(msgFifo != msgAnterior)
			printf("(%d msg recibidos) %s", msgRecibidos, msgFifo);
		strcpy(msgFifo, msgAnterior);
		msgRecibidos++;
		
	}
	return 0;
}

void manejador(){
	if(b){// con fichero
		printf("\nRegistradas %d peticiones en el fichero %s\n", peticiones, nombreFichero);
		close(fichero);
	}
	else// sin fichero
		printf("\nRegistradas %d peticiones en pantalla\n", peticiones);
	raise(SIGKILL);// termino el proceso
}

