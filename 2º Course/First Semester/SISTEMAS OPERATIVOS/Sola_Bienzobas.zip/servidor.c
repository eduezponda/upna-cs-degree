/*
 * Program: servidor
 * Version: 1.0
 * Date: 20/12/2022
 * Name: Fermin Sola
 */

#include "accionesSistema.h"

// ./servidor clave numLicencias nombreFIFO ficheroDeLog.txt --> ./servidor /etc 10 5 miFifo ficheroDeLog.txt 

int semaforo, pidHijo;// estas variables son globales porque he de utilizarlas en un manejador

void manejador();

int main(int argc, char **argv){
	if((argc != 5) && (argc != 6)){
		printf("ERROR: Introduce los datos correctamente\n");
		exit(1);
	}
	
	signal(SIGINT, manejador);
	key_t clave;
	int numLicencias = atoi(argv[3]), pid;
	char nombreFifo[20];
	strcpy(nombreFifo, argv[4]);
	int fifo;
	
	clave = creacionClave(argv[1], argv[2]);
	mkfifo(nombreFifo, 0777); 
	semaforo = creacionSemaforos(clave, 2);
	
	inicializarSemaforo(semaforo, semLicencias, numLicencias);
	inicializarSemaforo(semaforo, semPeticiones, 1);
	
	if(argc == 6){// hay fichero
		char nombreFichero[20];
		strcpy(nombreFichero, argv[5]);		
		if((pid = fork()) == -1){
			printf("ERROR: Creacion proceso logger\n");
			exit(1);
		}
		if(pid == 0){
			if((fifo = open(nombreFifo, O_RDONLY)) == -1){
				printf("ERROR: Apertura de la fifo\n");
				exit(1);
			}
			dup2(fifo,STDIN_FILENO);
			close(fifo);
			char *const arg[] = {"./logger", nombreFichero, NULL};
			execvp("./logger", arg);
		}
		pidHijo = pid;
	}
	else{
		if((pid = fork()) == -1){
			printf("ERROR: Creacion proceso logger\n");
			exit(1);
		}
		if(pid == 0){
			pidHijo = pid;
			if((fifo = open(nombreFifo, O_RDONLY)) == -1){
				printf("ERROR: Apertura de la fifo\n");
				exit(1);
			}
			dup2(fifo,STDIN_FILENO);
			close(fifo);
			char *const arg[] = {"./logger", NULL};
			execvp("./logger", arg);
		}
	}
	
	
	char msgFifo[100], msgFifoAnterior[100];
	while(1){/*
		
		if((fifo = open(nombreFifo, O_RDONLY)) == -1){
			printf("ERROR: Apertura de la fifo\n");
			exit(1);
		}
		printf("\n");
		//read(msgFifo, sizeof(msgFifo), 1, fifo);
		read(fifo, msgFifo, sizeof(msgFifo));
		if(msgFifoAnterior != msgFifo){
			printf("Desde el servidor --> %s", msgFifo);
		}
		strcpy(msgFifoAnterior, msgFifo);
		close(fifo);
		printf("\n");*/
	}
	
	return 0;
}

void manejador(){
	printf("\nFinalizando proceso servidor...");
	kill(pidHijo, SIGINT);
	eliminaSemaforos(semaforo, 0);
	printf("\nRecursos eliminados correctamente\n");
	raise(SIGKILL);// termino el proceso
}

