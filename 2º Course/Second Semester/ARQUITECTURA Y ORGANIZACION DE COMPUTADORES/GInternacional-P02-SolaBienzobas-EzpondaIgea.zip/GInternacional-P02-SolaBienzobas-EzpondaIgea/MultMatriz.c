#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#define N 1024

double A[N][N], B[N][N], C[N][N];

void main (){
    int i, j, k;

    for (i=0; i<N; i++)
        for (j=0; j<N; j++){
            A[i][j]= drand48();
            B[i][j]= drand48();
            C[i][j]= 0.0;
        }

    clock_t start = clock();
      
      /*
      * i j k --> 14.477159
      * j i k --> 17.374031
      * j k i --> 26.159956
      * k j i --> 28.129013
      * i k j --> 3.476741 <-- es el más rápido
      * k i j --> 3.535889
      */

	for (i=0; i<N; i++)
		for (k=0; k<N; k++)		
			for (j=0; j<N; j++)            
                C[i][j]=C[i][j]+A[i][k]*B[k][j];

    clock_t finish = clock();

    printf("Resultado: %lf, %lf, %lf\n", C[127][432], C[901][23], C[878][543]);
    printf("It took %f seconds to execute the loop.\n", (float)(finish-start)/CLOCKS_PER_SEC);
}
