#include <stdio.h>
#include <stdlib.h>
#include <time.h>

double A[64][1024*64];

void main () {
	int i, j, k;
	double cte1=0.0;

	printf ("Tama�o en bytes de una variable tipo \"double\": %ld\n", sizeof(double));

	for (i=0; i<64; i++)
		for (j=0; j<64*1024; j++)
			A[i][j]=drand48();
	
	clock_t start = clock();
	
	for (k=0; k<1500; k++)	
		for (j=0; j<64*1024; j++)
			for (i=0; i<64; i++)
				cte1=cte1+A[i][j];

	clock_t finish = clock();

  	printf("cte1=%lf\n", cte1);
	printf("It took %f seconds to execute the loop.\n", (float)(finish-start)/CLOCKS_PER_SEC);
}

