package utils;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Connection {
    private final Socket socket;
    private DataOutputStream out;
    private DataInputStream in;

    public Connection(Socket socket) {
        this.socket = socket;
    }

    public Connection(String server, int port) throws IOException {
        this.socket = new Socket(server, port);
    }

    public void connect() throws IOException {
        System.out.println("Connection from " + socket.getInetAddress() + ":" + socket.getPort());
        in = new DataInputStream(socket.getInputStream());
        out = new DataOutputStream(socket.getOutputStream());
    }

    public void disconnect() {
        try {
            socket.close();
        } catch (IOException ex) {
            Logger.getLogger(Connection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void sendMsg(String msg) {
        try {
            out.writeUTF(msg);
        } catch (IOException ex) {
            Logger.getLogger(Connection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public String recvMsg() {
        try {
            return in.readUTF();
        } catch (IOException ex) {
            Logger.getLogger(Connection.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    // static fields and methods
    public static String INTERNAL_SEP = ":";
    public static String INTERNAL_MSG = "/IM/:";

    //messages
    public static String EXIT = "/IM/:Exit:";
    public static String EXIT_ROOM = "/IM/:LeaveRoom:";
    public static String UPDATE_CLIENT = "/IM/:UpdateClients:";
    public static String UPDATE_ROOMS = "/IM/:Updaterooms:";
    public static String CHANGE_NAME = "/IM/:ChangeName:";
    public static String CHANGE_ROOM = "/IM/:ChangeRoom:";
    public static String SEND_MSG = "/IM/:Message:";
    

    public static String encodeUserNames(Collection<String> names) {
        return UPDATE_CLIENT + String.join(":", names);
    }

    public static List<String> decodeUserNames(String msg) {
        if (!msg.startsWith(UPDATE_CLIENT)) 
            return null;
        
        String[] parts = msg.split(INTERNAL_SEP);
        List<String> list = Arrays.asList(parts);
        return list.subList(2, list.size());
    }
}
