package p0;

import java.util.ArrayList;
import java.util.Arrays;

public class Kata2 {
    private String name;
    private double score;
    
    public Kata2 (String n, double s) {
        score = s;
        name = n;
    }
    
    public double Score () {
        return score;
    }
    
    public String Name () {
        return name;
    }
    
    public static void main (String[] args) {
        Kata2[] students = { 
            new Kata2("Aguirre Eguizabal, Endika", 8.0),
            new Kata2("Aldanondo Jimenez, Roberto", 6.5),
            new Kata2("Marzo Perez, Asier", 2.0),
            new Kata2("Barandiaran Lasheras, Nerea", 7.0),
            new Kata2("Barriuso Cervera, Pablo", 10.0),
            new Kata2("Bastida Vidaurre, Andrés", 8.7),
            new Kata2("Blasco Di Rosa, Sol", 9.0),
            new Kata2("No Name", 1.0),
            new Kata2("Diaz de Rada Beltran, Alba", 6.7),
            new Kata2("Martinez Martín", 0.0),
        };
        
        double avg = 0;
        
        for (Kata2 student : students) {
            avg += student.Score();
        }
        
        avg /= students.length;
        
        for (Kata2 s : students) {
            if (s.Score() > avg){
                System.out.println(s);
            }
        }
        
        Arrays.sort(students, 
                (s1, s2) -> Double.compare(s1.Score(), s2.Score()) );
                 
        for (Kata2 s : students) {
            System.out.println(s);
        }
        
        Arrays.sort(students, 
                (s1, s2) -> s1.Name().compareTo( s2.Name() ) );
        for (Student s : students) {
            System.out.println(s);
        }
    }
}
