package p0;

import java.util.ArrayList;
import java.util.Arrays;

public class Student {
    private String name;
    private double score;
    
    public Student (String n, double s) {
        score = s;
        name = n;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }
    
    //@Override
    
    public static void main (String[] args) {
       //List<Student> students = new ArrayList<>();
       Student[] students = { 
            new Student("Aguirre Eguizabal, Endika", 8.0),
            new Student("Aldanondo Jimenez, Roberto", 6.5),
            new Student("Marzo Perez, Asier", 2.0),
            new Student("Barandiaran Lasheras, Nerea", 7.0),
            new Student("Barriuso Cervera, Pablo", 10.0),
            new Student("Bastida Vidaurre, Andrés", 8.7),
            new Student("Blasco Di Rosa, Sol", 9.0),
            new Student("No Name", 1.0),
            new Student("Diaz de Rada Beltran, Alba", 6.7),
            new Student("Martinez Martín", 0.0),
        };

        double avg = 0;
        for (Student student : students) {
            avg += student.getScore();
        }
        avg /= students.length;
        
       /*final double avg2 = students.stream()
               .mapToDouble(Student::getScore)
               .average().orElse(0, 0);
*/
       
       //Student s = students.get(i);
       
       /*
       Collections.sort(students)
       for (Students : students) {
            
       }
       */
       /*
       OPTION1
       students.sort(
            (s1, s2) -> Double.compare( s1.getScore(), s2.getScore()));
       OPTION2
       students.sort (Comparator.comparing(Student::getScore));
*/
    }
}
