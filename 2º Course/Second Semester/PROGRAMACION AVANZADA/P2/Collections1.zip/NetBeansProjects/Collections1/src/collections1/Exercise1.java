/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package collections1;

import java.util.List;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;

public class Exercise1 {
    public static void main (String[] args){
        
        List<Student> students = new ArrayList<>();

        students.add(new Student("Aguirre Eguizabal, Endika", 8.0));
        students.add(new Student("Aldanondo Jimenez, Roberto", 6.5));
        students.add(new Student("Marzo Perez, Asier", 2.0));
        students.add(new Student("Barandiaran Lasheras, Nerea", 7.0));
        students.add(new Student("Barriuso Cervera, Pablo", 10.0));
        students.add(new Student("Bastida Vidaurre, Andrés", 8.7));
        students.add(new Student("Blasco Di Rosa, Sol", 9.0));
        students.add(new Student("No Name", 1.0));
        students.add(new Student("Diaz de Rada Beltran, Alba", 6.7));
        students.add(new Student("Martinez Martín", 0.0));
        
        
        students.sort(Comparator.comparing(Student::getScore));
        for (Student s : students) {
            System.out.println(s);
        }
        System.out.println();
        
        double avg = 0;
        for (Student student : students) {
            avg += student.getScore();
        }
        avg /= students.size();
        
        System.out.println("Students above the average");
        for (Student s : students) {
            if (s.getScore() > avg) {
                System.out.println(s.getName());
            }
        }
        
        //Exercise 2
        
        Map<String, Long> phoneNumbers = new HashMap<>();
        
        phoneNumbers.put("Santiago Ayechu", (long)675346732);
        phoneNumbers.put("Andrea Mazapán", (long)675346733);
        phoneNumbers.put("Ana María Amadoz", (long)674331733);
        phoneNumbers.put("Helen Portuondo", (long)621331563);
        phoneNumbers.put("Malena Paola Polvoron", (long)734211563);
        
        Iterator it = phoneNumbers.keySet().iterator();
        while(it.hasNext()){
            String key =  (String) it.next();
            System.out.println("Nombre: " + key + " -> Número: " + phoneNumbers.get(key));
        }
        
        //https://jarroba.com/map-en-java-con-ejemplos/
        
        

    }
    
}
