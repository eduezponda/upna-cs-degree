package practice1;


public class Box extends Rectangle implements Geometry3D{
    private double depth;

    public Box(double width, double height, double depth) {
        super(width, height);
        this.depth = depth;
    }

    //<editor-fold defaultstate="collapsed" desc="getters and setters">
    public double getDepth() {
        return depth;
    }
    public void setDepth(double depth) {
        this.depth = depth;
    }
//</editor-fold>
    
    public double getArea() {
        return 2.0 * (getWidth()*getHeight() 
                + getWidth()*getDepth()
                + getHeight()*getDepth());
    }

    public double getPerimeter() {
        return 4.0 * (getWidth() + getHeight() + getDepth());
    }

    public double getVolume() {
        return getWidth() * getHeight() * getDepth();
    }
}
