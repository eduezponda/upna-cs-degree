package practice1;


public class Circle implements Geometry{
    private double radious;

    public Circle(double radious) {
        this.radious = radious;
    }

    public double getRadious() {
        return radious;
    }

    public void setRadious(double radious) {
        this.radious = radious;
    }
    
    
    
    public double getPerimeter() {
        return Math.PI * radious * 2.0;
    }

    @Override
    public double getArea() {
        return Math.PI * radious * radious;
    }
    
}
