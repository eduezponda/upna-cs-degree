package practice1;


public interface Geometry {
    double getPerimeter();
    double getArea();
    
    public static double calcHypothenuse(double a, double b){
        return Math.sqrt(a*a + b*b);
    }
    
    public static double calcTriangleSide(double hypothenuse, double b){
        return Math.sqrt(hypothenuse*hypothenuse - b*b);
    }
}
