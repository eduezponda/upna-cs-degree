package practice1;

public interface Geometry3D extends Geometry{
    double getVolume();
}
