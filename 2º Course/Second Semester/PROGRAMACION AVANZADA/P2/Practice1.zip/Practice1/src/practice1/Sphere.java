package practice1;


public class Sphere extends Circle implements Geometry3D{

    public Sphere(double radious) {
        super(radious);
    }

    public double getArea() {
        return 4.0 * Math.PI * getRadious();
    }

    public double getVolume() {
        return 4.0/3.0*Math.PI * getRadious()*getRadious()*getRadious();
    } 
}
