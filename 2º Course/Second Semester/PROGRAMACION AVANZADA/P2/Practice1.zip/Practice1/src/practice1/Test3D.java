package practice1;


public class Test3D {
    public static void main(String[] args) {
        Geometry[] geoms = {
            new Circle(2.5),
            new Sphere(6.5),
            new Rectangle(6, 5.2),
            new Box(21, 1, 22),
            new Triangle(2.3, 1.2),
            new Tetrahedron(10, 1, 2),
            new Circle(8),
            new Sphere(20.1),
            new Rectangle(4,1),
            new Sphere(0.12),
            new Triangle(2, 2)
        };
        
        for (Geometry g : geoms) {
            System.out.println("******** " + g.getClass().getName());
            System.out.println("Area: " + g.getArea());
            System.out.println("Perimeter: " + g.getPerimeter());
            if (g instanceof Geometry3D) {
                Geometry3D g3 = (Geometry3D) g;
                System.out.println("Volume: " + g3.getVolume());
            }
        }
    }
}
