package practice1;


public class Tetrahedron extends Triangle implements Geometry3D{
    private double depth; 

    public Tetrahedron(double base, double height,double depth) {
        super(base, height);
        this.depth = depth;
    }

    public double getDepth() {
        return depth;
    }

    public void setDepth(double depth) {
        this.depth = depth;
    }

    public double calcUpwardsSide(){
        final double baseCorner = Geometry.calcHypothenuse(getBase()/2.0, getHeight()/2.0);
        return Geometry.calcHypothenuse(baseCorner, depth);
    }
    
    
    public double getArea() { //this is BS so do not pay attention to the actual formula
        final double heightUpwards = Geometry.calcTriangleSide( calcUpwardsSide(), getBase()/2.0);
        return super.getArea() + 3.0* (getBase()*heightUpwards/2.0);
    }

    public double getPerimeter() {
        return super.getPerimeter() + 3.0 * calcUpwardsSide();
    }

    public double getVolume() {
        return getBase()*getHeight()*getDepth() / 3.0;
    }
    
}
