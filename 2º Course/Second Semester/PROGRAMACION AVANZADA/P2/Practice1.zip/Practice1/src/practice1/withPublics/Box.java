package practice1.withPublics;


public class Box extends Rectangle implements Geometry3D{
    protected double depth;

    public Box(double width, double height, double depth) {
        super(width, height);
        this.depth = depth;
    }

    //<editor-fold defaultstate="collapsed" desc="getters and setters">
    public double getDepth() {
        return depth;
    }
    public void setDepth(double depth) {
        this.depth = depth;
    }
    //</editor-fold>
    
    public double getArea() {
        return 2.0 * (width*height 
                + width*depth
                + height*depth);
    }

    public double getPerimeter() {
        return 4.0 * (width + height + depth);
    }

    public double getVolume() {
        return width * height * depth;
    }
}
