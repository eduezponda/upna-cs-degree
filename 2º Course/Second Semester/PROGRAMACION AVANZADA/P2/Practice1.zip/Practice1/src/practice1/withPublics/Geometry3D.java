package practice1.withPublics;

import practice1.*;

public interface Geometry3D extends Geometry{
    double getVolume();
}
