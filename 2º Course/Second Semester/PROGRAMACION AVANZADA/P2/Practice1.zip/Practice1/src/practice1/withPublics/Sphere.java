package practice1.withPublics;

import practice1.*;


public class Sphere extends Circle implements Geometry3D{

    public Sphere(double radious) {
        super(radious);
    }

    public double getArea() {
        return 4.0 * Math.PI * radious;
    }

    public double getVolume() {
        return 4.0/3.0*Math.PI * radious*radious*radious;
    } 
}
