/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice1.withPublics;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class TEST3D {
    public static void main (String[] args){
        
         //ArrayList geoms = new ArrayList();
         List<Geometry> geoms = new LinkedList<>();
         
         geoms.add (new Sphere (3)); //añadir al final
         geoms.add(new Rectangle (3,2));
         
         for (Geometry g: geoms){ //Geometry g
             System.out.println(g.getArea());
             
         }
         for (int i = 0; i < geoms.size(); i++){
             Geometry g = geoms.get(i);
         }
         
         /*for (Iterator<Geometry> iter = geoms.iterator());
         
         interface Map<K,V>
            void put (key,value);
            V get (K key)
            Set <K> keySet()
            List <V> values
         
         interface Set <E>  -> una lista pero con estas dos características -> mismos métodos
            not repeated elements
            they are ordered
         
         */
            
            
        
    }
   
    
    
    
}
