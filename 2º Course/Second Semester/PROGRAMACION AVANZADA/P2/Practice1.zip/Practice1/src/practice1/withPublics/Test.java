package practice1.withPublics;

import practice1.*;


public class Test {
    public static void main(String[] args) {
        Geometry[] geoms = {
            new Circle(2.5),
            new Rectangle(6, 5.2),
            new Triangle(2.3, 1.2)
        };
        
        for (Geometry g : geoms) {
            System.out.println("************");
            System.out.println("Area: " + g.getArea());
            System.out.println("Perimeter: " + g.getPerimeter());
        }
    }
}
