package practice1.withPublics;

import java.text.DecimalFormat;


public class Test3D {
    public static void main(String[] args) {
        Geometry[] geoms = {
            new Circle(2.5),
            new Sphere(6.5),
            new Rectangle(6, 5.2),
            new Box(21, 1, 22),
            new Triangle(2.3, 1.2),
            new Tetrahedron(10, 1, 2),
            new Circle(8),
            new Sphere(20.1),
            new Rectangle(4,1),
            new Sphere(0.12),
            new Triangle(2, 2)
        };
        
        DecimalFormat df = new DecimalFormat();
        df.setMaximumFractionDigits(2);
        df.setMinimumFractionDigits(2);

        for (Geometry g : geoms) {
            System.out.println("******** " + g.getClass().getSimpleName());
            System.out.println("Area: " + df.format( g.getArea() ));
            System.out.println("Perimeter: " + df.format( g.getPerimeter() ));
            if (g instanceof Geometry3D) {
                Geometry3D g3 = (Geometry3D) g;
                System.out.println("Volume: " + df.format( g3.getVolume() ));
            }
        }
    }
}
