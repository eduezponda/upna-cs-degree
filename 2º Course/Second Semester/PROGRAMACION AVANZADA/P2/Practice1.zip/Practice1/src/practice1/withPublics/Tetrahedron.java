package practice1.withPublics;

import practice1.*;


public class Tetrahedron extends Triangle implements Geometry3D{
    protected double depth; 

    public Tetrahedron(double base, double height,double depth) {
        super(base, height);
        this.depth = depth;
    }

    public double getDepth() {
        return depth;
    }

    public void setDepth(double depth) {
        this.depth = depth;
    }

    public double calcUpwardsSide(){
        final double baseCorner = Geometry.calcHypothenuse(base/2.0, height/2.0);
        return Geometry.calcHypothenuse(baseCorner, depth);
    }
    
    
    public double getArea() { //this is BS so do not pay attention to the actual formula
        final double heightUpwards = Geometry.calcTriangleSide( calcUpwardsSide(), getBase()/2.0);
        return super.getArea() + 3.0* (base*heightUpwards/2.0);
    }

    public double getPerimeter() {
        return super.getPerimeter() + 3.0 * calcUpwardsSide();
    }

    public double getVolume() {
        return base*height*depth / 3.0;
    }
    
}
