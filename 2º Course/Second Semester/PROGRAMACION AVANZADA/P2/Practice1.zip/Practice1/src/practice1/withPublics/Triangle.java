package practice1.withPublics;

import practice1.*;

public class Triangle implements Geometry{
    protected double base;
    protected double height;

    //<editor-fold defaultstate="collapsed" desc="cgs">
    public Triangle(double base, double height) {
        this.base = base;
        this.height = height;
    }
    
    public double getBase() {
        return base;
    }
    
    public void setBase(double base) {
        this.base = base;
    }
    
    public double getHeight() {
        return height;
    }
    
    public void setHeight(double height) {
        this.height = height;
    }
//</editor-fold>
    
    public double getPerimeter() {
        final double side = Geometry.calcHypothenuse(height, base/2.0);
        return 2.0*side + base;
    }

    public double getArea() {
        return base * height / 2.0;
    }
    
}
