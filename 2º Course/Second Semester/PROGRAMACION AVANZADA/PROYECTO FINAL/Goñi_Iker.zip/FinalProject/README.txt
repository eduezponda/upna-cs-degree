There are two ways to Play:
	Single player
		- Run the file with name LocalExecutor.java
	MultiPlayer
		- Firstly run the file ServerRunnable.java
		- Then run twice the file ClientRunnable.java

How to play:
	Single Player Mode:
		You always have the control of the same team
	MultiPlayer Mode:
		You sometimes have the control to attack and then to deffend but always the same team

	Both Modes (Attacking):
		- When you start playing one of the teams would have the ball. 
		- To pass the ball between different players of the same team you just have to 
		click on the player who wanted the ball.
		- If you want to move arround the peach, you only have to click where you want to go even if the last
		move hasn't ended.
		- When the ball stop moving the time will pause to think what you prefer to do.
		- To shoot and score a goal you have to move the mouse pressed drawing the movement
		of the ball.
		- If the ball get into the goal,  the team who scored will get a point on the scoreboard.
		- If the ball go out the peach, the play would start again but "on the other team's peach"
		(the goals would sum for the other team).
		- If someone reaches 2 goals more than the other, he will win but if both reach 5 goals or more, it 
		will be a tie.
	
	Both Modes (Deffending):
		- To choose the player you want to control, just click on it.
		- If you want to move arround, click where you want to go.
		- If you want to steal the ball move next to the ball and automatically it will be yours.
		- If you want to attack so you can score a goal, first steal the ball or let that your goalkeeper
		steal it for you, and then throw it out of the peach.
