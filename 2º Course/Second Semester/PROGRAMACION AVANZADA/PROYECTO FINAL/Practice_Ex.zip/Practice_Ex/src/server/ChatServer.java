package server;

import static java.lang.Thread.interrupted;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class ChatServer extends Thread {

    public static void main(String[] args) {
        ChatServer cs = new ChatServer(12000);
        cs.start();
    }

    final int port;
    final Map<String, Room> rooms = new HashMap<>();
    final List<ClientThread> allClients = new LinkedList<>();
    
    private static int pass = 12345;
    private int nRooms = 6;

    public static int getPass() {
        return pass;
    }

    public int getnRooms() {
        return nRooms;
    }
    
    public void setnRooms(int nRooms) {
        this.nRooms = nRooms;
    }
    
    public ChatServer(int port) {
        this.port = port;
        for (int i = 1; i <= nRooms; i++) {
            String roomName = "Room " + i;
            rooms.put(roomName, new Room(roomName));
        }
    }

    @Override
    public void run() {
        try ( ServerSocket serverSocket = new ServerSocket(port) ) {
            System.out.println("Started server on port " + port);
            while ( !interrupted() ) {
                Socket clientSocket = serverSocket.accept();
                ClientThread clientThread = new ClientThread(clientSocket, rooms, allClients);
                clientThread.start();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
