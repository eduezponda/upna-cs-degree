package server;

import utils.Connection;
import java.io.IOException;
import java.net.Socket;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ClientThread extends Thread {

    final List<ClientThread> allClients;
    final Map<String, Room> rooms;
    private Room currentRoom = null;
    Connection connection;
    String name;

    public ClientThread(Socket socket, Map<String, Room> rooms, List<ClientThread> allClients) {
        this.allClients = allClients;
        this.connection = new Connection(socket);
        this.rooms = rooms;
        name = "nONaMe";
    }

    public String getNickName() {
        return name;
    }

    public void connect() throws IOException {
        connection.connect();
        synchronized (allClients) {
            allClients.add(this);
        }
        connection.sendMsg(encodeRoomNames());
    }

    public String encodeRoomNames() {
        Set<String> roomNames = null;
        synchronized (rooms) {
            roomNames = rooms.keySet();
        }
        return Room.encodeNames(roomNames);
    }

    synchronized public void joinRoom(String name) {
        if (rooms.containsKey(name)) {
            currentRoom = rooms.get(name);
            currentRoom.join(this);
        }
    }

    public void leaveRoom() {
        if (currentRoom != null) {
            currentRoom.leave(this);
            currentRoom = null;
        }
    }

    public Connection getConnection() {
        return connection;
    }

    synchronized public void sendToAll(String msg) {
        if (allClients != null) {
            allClients.forEach(c -> c.getConnection().sendMsg(msg));
        }
    }



    @Override
    public void run() {
        try {
            connect();
            for (String line; (line = connection.recvMsg()) != null;) {
                System.out.println(line);
                if (!line.startsWith(Connection.INTERNAL_MSG)) {
                    if (currentRoom != null) {
                        currentRoom.sendMsg(name + ": " + line);
                        String[] lineToArray = line.split(" ");
                        //System.out.println("0:" + lineToArray[0] + " 1:" + lineToArray[1]);
                        if (lineToArray[0].equalsIgnoreCase("/admin")) {
                            if (lineToArray.length > 1) {
                                if (Integer.parseInt(lineToArray[1]) == ChatServer.getPass()) {
                                    connection.sendMsg("/adminok");
                                }
                            }
                        }
                    } else {
                        connection.sendMsg("Join a room to speak with people");
                    }
                } else {
                    String[] lineToArray = line.split(" ");
                    if (lineToArray[0].equals(Connection.NEW_ROOM)){
                        System.out.println("before: " + rooms);
                        rooms.put("Room " + lineToArray[1], new Room("Room " + lineToArray[1]));
                        System.out.println("after: " + rooms);
                        connection.sendMsg(Connection.UPDATE_ROOMS + rooms.keySet());
                    }
                    else if (lineToArray[0].equals(Connection.REMOVE_ROOM)) {
                        System.out.println("before: " + rooms);
                        rooms.remove("Room " + lineToArray[1]);
                        System.out.println("after: " + rooms);
                        connection.sendMsg(Connection.UPDATE_ROOMS + rooms.keySet());
                    }
                    else if (line.startsWith(Connection.CHANGE_ROOM)) {
                        leaveRoom();
                        line = line.replaceAll(Connection.CHANGE_ROOM, "");
                        joinRoom(line);
                        connection.sendMsg("You moved to room " + currentRoom.getNombre());
                    } else if (line.startsWith(Connection.EXIT)) {
                        leaveRoom();
                        connection.sendMsg(Connection.EXIT);
                        break;
                    } else if (line.startsWith(Connection.CHANGE_NAME)) {
                        name = line.replaceAll(Connection.CHANGE_NAME, "");
                        connection.sendMsg("Your nickname is " + name);
                        if(currentRoom != null){
                            currentRoom.updateClients();
                        }
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                connection.disconnect();
            } catch (Exception ex) {}
            leaveRoom();
        }
    }

    @Override
    public String toString() {
        return name;
    }

}
