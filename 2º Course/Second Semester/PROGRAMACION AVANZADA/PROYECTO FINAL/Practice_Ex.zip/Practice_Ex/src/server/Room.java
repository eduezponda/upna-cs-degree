package server;

import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import utils.Connection;

public class Room extends Thread {

  

    private final List<ClientThread> clients = new LinkedList<>();
    private String name;

    public Room() {
    }
    public Room(String name) {
        this.name=name;
    }

    public String getNombre() {
        return name;
    }

 
    public void setNombre(String nombre) {
        this.name = nombre;
    }

    public List<ClientThread> getClients() {
        return clients;
    }

    synchronized public void join(ClientThread client) {
        clients.add(client);
        updateClients();
    }

    synchronized public void leave(ClientThread client) {
        clients.remove(client);
        client.getConnection().sendMsg(Connection.EXIT_ROOM);
        updateClients();
    }

    synchronized public void updateClients() {
        List<String> names = new LinkedList<>();

        for (ClientThread c : clients) {
            names.add(c.getNickName());
        }
        sendMsg(Connection.encodeUserNames(names));
    }
    
    synchronized public void sendMsg(String msg) {
        clients.forEach(c -> c.getConnection().sendMsg(msg));
    }

    @Override
    public String toString() {
        return name + "    (" + clients.size() + ")";
    }
    
      public static String encodeNames(Collection<String> names) {
        return Connection.UPDATE_ROOMS + String.join(":", names);
    }

    public static List<String> decodeNames(String msg) {
        if (!msg.startsWith(Connection.UPDATE_ROOMS)) {
            return null;
        }
        String[] parts = msg.split(Connection.INTERNAL_SEP);
        List<String> list = Arrays.asList(parts);
        return list.subList(2, list.size());
    }
}
