use db;
CREATE TABLE information(
	messageID int not null AUTO_INCREMENT,
	message varchar(255) NOT NULL,
	PRIMARY KEY (messageID)
);


