import mysql.connector
import pylint
import subprocess

def analizar_codigo():
    return subprocess.getoutput('pylint python/url.py')

def registrar_mensaje(mensaje):
	connection = mysql.connector.connect(
		user='root', password='root', host='mysql', port="3306",
		database='db')
	print("DB connected")

	cursor = connection.cursor()
	sql = "INSERT INTO information (message) VALUES (%s)"
	"""Divido el comando en varios porque message VARCHAR2(255) ->  """
	for linea in mensaje.splitlines():
		cursor.execute(sql, (linea,))
	connection.commit()
	print("Message inserted successfully")
	connection.close()

def main():
    mensaje_analisis = analizar_codigo()
    print(mensaje_analisis)
    registrar_mensaje(mensaje_analisis)

if __name__ == "__main__":
    main()
