import requests

def leer_url(url):
    response = requests.get(url)
    return response.content.decode('utf-8')

def almacenar_informacion(informacion, nombre_archivo):
    with open(nombre_archivo, 'w', encoding='utf-8') as f:
        f.write(informacion)
        
def main():
    url = "https://www.myorganicrevolution.com/about/"
    informacion = leer_url(url)
    almacenar_informacion(informacion, "informacion.txt")
 

if __name__ == "__main__":
    main()


