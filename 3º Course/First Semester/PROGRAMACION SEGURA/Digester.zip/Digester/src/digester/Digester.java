package digester;
/**
 *
 * @author MAZ
 */
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Logger;
//
public final class Digester {
  
  static private final String CLASS_NAME = Digester.class.getName();
  static private final Logger LOGGER = Logger.getLogger(CLASS_NAME);

  private final MessageDigest md;

  public Digester (final String algorithm) throws NoSuchAlgorithmException {
    try {
      this.md = MessageDigest.getInstance(algorithm);
    } catch (final NoSuchAlgorithmException ex) {
      throw new NoSuchAlgorithmException(algorithm);
    }
  }

  public String getAlgorithm () {
    return md.getAlgorithm();
  }

  public byte[] digest (final byte[] bytes) {

    return new byte[0];
    
  }

  public byte[] digest (final InputStream is) throws IOException {
    
    return new byte[0];
    
  }

}