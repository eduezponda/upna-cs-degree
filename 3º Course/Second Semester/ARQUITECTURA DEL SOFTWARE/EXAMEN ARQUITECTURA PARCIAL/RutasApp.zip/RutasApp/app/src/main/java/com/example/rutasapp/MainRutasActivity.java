package com.example.rutasapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.rutasapp.Modelos.Ruta;
import com.example.rutasapp.R;
import com.example.rutasapp.RutasApplication;

import java.util.List;

public class MainRutasActivity extends AppCompatActivity {

    private ListView listView;
    private ArrayAdapter<Ruta> todoItemsAdapter;
    private RutasApplication app;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_rutas);
        setTitle("Rutas Montaña");
        listView = findViewById(R.id.list_rutas);
        app = (RutasApplication) getApplicationContext();

        List<Ruta> rutas = app.getRutas();
        String[] formattedRutas = formatRutasList(rutas);
        ArrayAdapter<String> rutaAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, formattedRutas);
        listView.setAdapter(rutaAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(MainRutasActivity.this, PuntosRutaActivity.class);
                intent.putExtra("rutaIndex", position);
                startActivity(intent);
            }
        });
    }

    private String[] formatRutasList(List<Ruta> rutas) {
        String[] formattedRutas = new String[rutas.size()];
        for (int i = 0; i < rutas.size(); i++) {
            Ruta ruta = rutas.get(i);
            formattedRutas[i] = "Ruta " + (i + 1) + ": Inicio " + ruta.getOrigen() + ", Final " + ruta.getDestino();
        }
        return formattedRutas;
    }
}
