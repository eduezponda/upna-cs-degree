package com.example.rutasapp;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toolbar;

import com.example.rutasapp.Modelos.Punto;
import com.example.rutasapp.Modelos.Ruta;
import com.example.rutasapp.R;
import com.example.rutasapp.RutasApplication;

import java.util.List;

public class PuntosRutaActivity extends Activity {
    private ListView listView;
    private ArrayAdapter<String> puntoAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_puntos_ruta);
        listView = findViewById(R.id.list_puntos);
        RutasApplication app = (RutasApplication) getApplicationContext();

        int rutaIndex = getIntent().getIntExtra("rutaIndex", -1);
        if (rutaIndex != -1) {
            setTitle("Recorrido Ruta " + (rutaIndex + 1));
            Ruta ruta = app.getRutas().get(rutaIndex);
            List<Punto> puntosDeRuta = ruta.getPuntos();
            puntoAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, formatPuntosList(puntosDeRuta));
            listView.setAdapter(puntoAdapter);
        }
    }

    private String[] formatPuntosList(List<Punto> puntos) {
        String[] formattedPuntos = new String[puntos.size()];
        for (int i = 0; i < puntos.size(); i++) {
            Punto punto = puntos.get(i);
            formattedPuntos[i] = "Punto " + (i + 1) + ": " + punto.getNombre() + " " + punto.getLatitud() + ", " + punto.getLongitud();
        }
        return formattedPuntos;
    }
}
