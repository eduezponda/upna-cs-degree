package com.example.RutasMaterialApp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.RutasMaterialApp.Modelos.Ruta;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class MainRutasMaterialActivity extends AppCompatActivity {

    ListView listView;
    ArrayAdapter<String> rutaAdapter;
    RutasApplication app;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_rutas);
        setTitle("Rutas Montaña");
        listView = findViewById(R.id.list_rutas);
        FloatingActionButton fabAddRuta = findViewById(R.id.fab_add_ruta);
        app = (RutasApplication) getApplicationContext();

        List<Ruta> rutas = app.getRutas();
        String[] formattedRutas = formatRutasList(rutas);
        rutaAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, formattedRutas);
        listView.setAdapter(rutaAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), PuntosRutaActivity.class);
                intent.putExtra("rutaIndex", position);
                startActivity(intent);
            }
        });

        fabAddRuta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainRutasMaterialActivity.this, NuevaRutaActivity.class);
                startActivityForResult(intent, 1);
            }
        });
    }

    private String[] formatRutasList(List<Ruta> rutas) {
        String[] formattedRutas = new String[rutas.size()];
        for (int i = 0; i < rutas.size(); i++) {
            Ruta ruta = rutas.get(i);
            formattedRutas[i] = "Ruta " + (i + 1) + ": Inicio " + ruta.getOrigen() + ", Final " + ruta.getDestino();
        }
        return formattedRutas;
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            // Obtener los datos de origen y destino devueltos por NuevaRutaActivity
            String origen = data.getStringExtra("origen");
            String destino = data.getStringExtra("destino");

            // Crear la nueva ruta y agregarla a la lista de rutas
            app.add(origen, destino);
            // Actualizar la lista de rutas en la interfaz de usuario
            List<Ruta> rutas = app.getRutas();
            String[] formattedRutas = formatRutasList(rutas);
            ArrayAdapter<String> newRutaAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, formattedRutas);

            // Asignar el nuevo adaptador a la lista
            listView.setAdapter(newRutaAdapter);

        }
    }
}
