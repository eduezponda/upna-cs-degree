// Ruta.java
package com.example.RutasMaterialApp.Modelos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Ruta implements Serializable {
    private String origen;
    private String destino;
    private List<Punto> puntos;

    public Ruta(String origen, String destino, List<Punto> puntos) {
        this.origen = origen;
        this.destino = destino;
        this.puntos = puntos;
    }

    public String getOrigen() {
        return origen;
    }

    public String getDestino() {
        return destino;
    }

    public List<Punto> getPuntos() {
        return puntos;
    }

    public void addPunto(int index, Punto punto) {
        if (puntos == null) {
            puntos = new ArrayList<>();
        }
        puntos.add(index-1, punto);
    }
}
