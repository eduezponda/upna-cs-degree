package com.example.RutasMaterialApp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class NuevaRutaActivity extends AppCompatActivity {
    private EditText editTextOrigen;
    private EditText editTextDestino;
    private Button buttonGuardar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nueva_ruta);
        setTitle("Nueva Ruta");

        editTextOrigen = findViewById(R.id.edit_text_origen);
        editTextDestino = findViewById(R.id.edit_text_destino);
        buttonGuardar = findViewById(R.id.button_guardar);
        buttonGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtener el origen y el destino ingresados por el usuario
                String origen = editTextOrigen.getText().toString();
                String destino = editTextDestino.getText().toString();

                // Crear un Intent para enviar los datos de vuelta a MainRutasMaterialActivity
                Intent intent = new Intent();
                intent.putExtra("origen", origen);
                intent.putExtra("destino", destino);
                setResult(RESULT_OK, intent);
                finish(); // Finalizar esta actividad y volver a la actividad anterior
            }
        });
    }
}