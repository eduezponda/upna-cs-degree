package com.example.RutasMaterialApp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class NuevoPuntoActivity extends AppCompatActivity {
    private EditText editTextNombre;
    private EditText editTextLatitud;
    private EditText editTextLongitud;
    private EditText editTextPosicion;
    private Button buttonGuardar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuevo_punto);
        setTitle("Nuevo Punto");
        editTextNombre = findViewById(R.id.edit_text_nombre);
        editTextLatitud = findViewById(R.id.edit_text_latitud);
        editTextLongitud = findViewById(R.id.edit_text_longitud);
        editTextPosicion = findViewById(R.id.edit_text_posicion);
        buttonGuardar = findViewById(R.id.button_guardar);

        buttonGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombre = editTextNombre.getText().toString();
                double latitud = Double.parseDouble(editTextLatitud.getText().toString());
                double longitud = Double.parseDouble(editTextLongitud.getText().toString());
                int posicion = Integer.parseInt(editTextPosicion.getText().toString());
                Intent intent = new Intent();
                intent.putExtra("nombre", nombre);
                intent.putExtra("latitud", latitud);
                intent.putExtra("longitud", longitud);
                intent.putExtra("posicion", posicion);
                setResult(RESULT_OK, intent);

                finish();
            }
        });
    }
}
