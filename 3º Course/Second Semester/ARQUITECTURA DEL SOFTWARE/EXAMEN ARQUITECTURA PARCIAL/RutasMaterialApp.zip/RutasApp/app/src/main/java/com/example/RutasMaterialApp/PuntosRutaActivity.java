package com.example.RutasMaterialApp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toolbar;

import androidx.appcompat.app.AppCompatActivity;

import com.example.RutasMaterialApp.Modelos.Punto;
import com.example.RutasMaterialApp.Modelos.Ruta;
import com.example.RutasMaterialApp.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class PuntosRutaActivity extends AppCompatActivity {
    private ListView listView;
    private ArrayAdapter<String> puntoAdapter;
    private RutasApplication app;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_puntos_ruta);
        listView = findViewById(R.id.list_puntos);
        FloatingActionButton fabAddPunto = findViewById(R.id.fab_add_punto);
        app = (RutasApplication) getApplicationContext();

        int rutaIndex = getIntent().getIntExtra("rutaIndex", -1);
        if (rutaIndex != -1) {
            Ruta ruta = app.getRutas().get(rutaIndex);
            String titulo = "Recorrido Ruta " + (rutaIndex + 1) + ": " + ruta.getOrigen() + " " + ruta.getDestino();
            setTitle(titulo);
            List<Punto> puntosDeRuta = ruta.getPuntos();
            puntoAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, formatPuntosList(puntosDeRuta));
            listView.setAdapter(puntoAdapter);
        }

        fabAddPunto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Abrir NuevoPuntoActivity
                Intent intent = new Intent(PuntosRutaActivity.this, NuevoPuntoActivity.class);
                startActivityForResult(intent, 1);
            }
        });
    }

    private String[] formatPuntosList(List<Punto> puntos) {
        String[] formattedPuntos = new String[puntos.size()];
        for (int i = 0; i < puntos.size(); i++) {
            Punto punto = puntos.get(i);
            formattedPuntos[i] = "Punto " + (i + 1) + ": " + punto.getNombre() + " " + punto.getLatitud() + ", " + punto.getLongitud();
        }
        return formattedPuntos;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            // Obtener los datos del nuevo punto de NuevoPuntoActivity
            String nombre = data.getStringExtra("nombre");
            double latitud = data.getDoubleExtra("latitud", 0);
            double longitud = data.getDoubleExtra("longitud", 0);
            int index = data.getIntExtra("posicion", 0);
            // Crear el nuevo punto
            Punto punto = new Punto(nombre, latitud, longitud);
            int rutaIndex = getIntent().getIntExtra("rutaIndex", -1);
            // Añadir el nuevo punto a la lista de puntos de la ruta correspondiente
            List<Ruta> rutas = app.getRutas();

            // Verificar que el índice de la ruta está dentro de los límites
            if (rutaIndex >= 0 && rutaIndex < rutas.size()) {
                // Obtener la ruta correspondiente al índice
                Ruta ruta = rutas.get(rutaIndex);

                // Añadir el nuevo punto a la lista de puntos de la ruta correspondiente
                app.addPuntoToRuta(rutaIndex, punto, index);
                Log.d("Puntos de la ruta", "Puntos de la ruta después de agregar el nuevo punto:");
                for (Punto p : ruta.getPuntos()) {
                    Log.d("Punto", p.getNombre() + ": Latitud - " + p.getLatitud() + ", Longitud - " + p.getLongitud());
                }

                // Actualizar el adaptador de la lista de puntos
                List<Punto> puntos = ruta.getPuntos();
                String[] formattedPuntos = formatPuntosList(puntos);
                ArrayAdapter<String> newPuntoAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, formattedPuntos);

                // Asignar el nuevo adaptador a la lista
                listView.setAdapter(newPuntoAdapter);
            }
        }
    }
}
