// RutasApplication.java
package com.example.RutasMaterialApp;

import android.app.Application;

import com.example.RutasMaterialApp.Modelos.Punto;
import com.example.RutasMaterialApp.Modelos.Ruta;

import java.util.ArrayList;
import java.util.List;

public class RutasApplication extends Application {
    public List<Ruta> rutas;

    @Override
    public void onCreate() {
        super.onCreate();
        initializeRutas();
    }

    public List<Ruta> getRutas() {
        return rutas;
    }

    private void initializeRutas() {
        rutas = new ArrayList<>();

        List<Punto> puntosRuta1 = new ArrayList<>();
        puntosRuta1.add(new Punto("Plaza Castillo", 42.81, -1.65));
        puntosRuta1.add(new Punto("Artica", 42.83, -1.65));
        puntosRuta1.add(new Punto("Carretera San Cristobal", 42.84, -1.65));
        puntosRuta1.add(new Punto("Fuerte San Cristobal", 42.85, -1.65));
        rutas.add(new Ruta("Pamplona", "San Cristóbal", puntosRuta1));

        List<Punto> puntosRuta2 = new ArrayList<>();
        puntosRuta2.add(new Punto("Plaza Irurzun", 62.81, -2.64));
        puntosRuta2.add(new Punto("Carretera Dos Hermanas", 72.88, -2.64));
        puntosRuta2.add(new Punto("Dos Hermanas", 92.80, -2.64));
        rutas.add(new Ruta("Irurzun", "Dos Hermanas", puntosRuta2));

        List<Punto> puntosRuta3 = new ArrayList<>();
        puntosRuta3.add(new Punto("Plaza de Lecumberri", 32.81, -1.64));
        puntosRuta3.add(new Punto("Baraibar", 12.80, -1.64));
        puntosRuta3.add(new Punto("Sierra Aralar", 22.78, -1.65));
        rutas.add(new Ruta("Lecumberri", "Aralar", puntosRuta3));


    }

    public void add(String origen, String destino){
        rutas.add(new Ruta(origen, destino, new ArrayList<Punto>()));
    }

    public void addPuntoToRuta(int rutaIndex, Punto punto, int index) {
        if (rutaIndex >= 0 && rutaIndex < rutas.size()) {
            Ruta ruta = rutas.get(rutaIndex);
            ruta.addPunto(index, punto);
        }
    }
}
