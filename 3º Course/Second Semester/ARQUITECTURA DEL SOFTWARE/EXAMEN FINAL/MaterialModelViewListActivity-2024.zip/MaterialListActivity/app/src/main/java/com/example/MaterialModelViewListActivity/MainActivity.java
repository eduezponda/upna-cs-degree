package com.example.MaterialModelViewListActivity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import com.example.MaterialModelViewListActivity.Modelos.InterestPoint;
import com.example.MaterialModelViewListActivity.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    ListView listView;
    ArrayAdapter<InterestPoint> todoItemsAdapter;

    TravelPointApplication tpa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        tpa = (TravelPointApplication)getApplicationContext();
        tpa.initializeList();
        listView = (ListView) findViewById(R.id.list);

        todoItemsAdapter = new ArrayAdapter<InterestPoint>(this, R.layout.row_layout, R.id.listText, tpa.getPointList());
        listView.setAdapter(todoItemsAdapter);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.action_reload) {


        }
        if (id == R.id.action_new) {

        }
        return super.onOptionsItemSelected(item);
    }

}