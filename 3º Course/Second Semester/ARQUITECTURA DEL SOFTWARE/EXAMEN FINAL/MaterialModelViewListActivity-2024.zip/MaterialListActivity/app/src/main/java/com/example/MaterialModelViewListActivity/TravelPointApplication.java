package com.example.MaterialModelViewListActivity;

import android.app.Application;

import com.example.MaterialModelViewListActivity.Modelos.InterestPoint;

import java.util.ArrayList;
import java.util.List;

public class TravelPointApplication extends Application {


    private List<InterestPoint> pointList = new ArrayList<>();

    @Override
    public void onCreate() {
        super.onCreate();
    }

    public  List<InterestPoint> getPointList()
    {
        return pointList;

    }

    public  InterestPoint getPoint(int position)
    {
        return pointList.get(position);

    }
    public  void addPoint(InterestPoint aInterestPoint)
    {
        pointList.add(aInterestPoint);

    }
    public void initializeList() {

        pointList.clear();
        InterestPoint aInterestPoint;
        Double latitud = 43.34343;
        Double longitud = 2.34343;

        for(int i=0; i<5; i++){
            aInterestPoint = new InterestPoint();
            aInterestPoint.setNombre("mismo nombre");
            aInterestPoint.setLatitud(latitud+i);
            aInterestPoint.setLongitud(longitud+i);
            addPoint(aInterestPoint);

        }
    }




}

