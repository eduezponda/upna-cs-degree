package com.example.MaterialModelViewListActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.MaterialModelViewListActivity.Modelos.LinePoint;
import com.example.MaterialModelViewListActivity.Modelos.StationPoint;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class LineStationsActivity extends AppCompatActivity {
    private ListView listView;
    private ArrayAdapter<String> puntoAdapter;
    private TravelPointApplication app;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_line_stations);

        listView = findViewById(R.id.list_puntos);
        FloatingActionButton fabAddPunto = findViewById(R.id.fab_add_punto);
        app = (TravelPointApplication) getApplicationContext();

        int lineIndex = getIntent().getIntExtra("lineIndex", -1);
        if (lineIndex != -1) {
            LinePoint linePoint = app.getPointList().get(lineIndex);
            String titulo = "Linea " + linePoint.getOrigin() + "-" + linePoint.getDestination();
            setTitle(titulo);
            List<StationPoint> stationPointList = linePoint.getStationPoints();

            String[] formattedStationPoints = formatStationList(stationPointList);
            puntoAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, formattedStationPoints);
            listView.setAdapter(puntoAdapter);
        }

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), StationHoursActivity.class);
                intent.putExtra("stationIndex", position);
                startActivity(intent);
            }
        });

        fabAddPunto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Abrir NuevoPuntoActivity
                Intent intent = new Intent(LineStationsActivity.this, NewStationActivity.class);
                startActivityForResult(intent, 1);
            }
        });
    }

    private String[] formatStationList(List<StationPoint> stationPointList) {
        String[] formattedStations = new String[stationPointList.size()];
        for (int i = 0; i < stationPointList.size(); i++) {
            StationPoint stationPoint = stationPointList.get(i);
            formattedStations[i] = "Estacion " + (i + 1) + " " + stationPoint.getName();
        }
        return formattedStations;
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            String station = data.getStringExtra("station");

            int lineIndex = getIntent().getIntExtra("lineIndex", -1);
            LinePoint linePoint = app.getPointList().get(lineIndex);
            List<StationPoint> stationPointList = linePoint.getStationPoints();

            StationPoint stationPoint = new StationPoint(station, stationPointList.size() + 1);

            linePoint.addStation(stationPoint);

            String[] formattedLines = formatStationList(stationPointList);
            ArrayAdapter<String> newRutaAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, formattedLines);

            listView.setAdapter(newRutaAdapter);

        }
    }
}