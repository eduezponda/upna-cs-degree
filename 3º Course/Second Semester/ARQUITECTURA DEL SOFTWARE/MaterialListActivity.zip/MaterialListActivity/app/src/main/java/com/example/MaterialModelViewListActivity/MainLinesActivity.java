package com.example.MaterialModelViewListActivity;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import com.example.MaterialModelViewListActivity.Modelos.LinePoint;
import com.example.MaterialModelViewListActivity.databinding.ActivityMainBinding;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainLinesActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    ListView listView;
    ArrayAdapter<LinePoint> todoItemsAdapter;

    TravelPointApplication tpa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setTitle("Lineas tren");

        setSupportActionBar(binding.toolbar);

        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        tpa = (TravelPointApplication)getApplicationContext();
        tpa.initializeList();
        listView = (ListView) findViewById(R.id.list);

        todoItemsAdapter = new ArrayAdapter<LinePoint>(this, R.layout.row_layout, R.id.listText, tpa.getPointList());
        listView.setAdapter(todoItemsAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), LineStationsActivity.class);
                intent.putExtra("lineIndex", position);
                startActivity(intent);
            }
        });

        FloatingActionButton fabAddRuta = findViewById(R.id.fab);
        fabAddRuta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainLinesActivity.this, NewLineActivity.class);
                startActivityForResult(intent, 1);
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            String origen = data.getStringExtra("origen");
            String destino = data.getStringExtra("destino");

            tpa.addPoint(new LinePoint(origen,destino));
            List<LinePoint> lines = tpa.getPointList();
            String[] formattedLines = formatLinesList(lines);
            ArrayAdapter<String> newRutaAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, formattedLines);

            listView.setAdapter(newRutaAdapter);

        }
    }

    private String[] formatLinesList(List<LinePoint> lines) {
        String[] formattedLines = new String[lines.size()];
        for (int i = 0; i < lines.size(); i++) {
            LinePoint line = lines.get(i);
            formattedLines[i] = "Linea " + line.getOrigin() + "-" + line.getDestination();
        }
        return formattedLines;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.action_reload) {

        }
        if (id == R.id.action_new) {

        }
        return super.onOptionsItemSelected(item);
    }

}