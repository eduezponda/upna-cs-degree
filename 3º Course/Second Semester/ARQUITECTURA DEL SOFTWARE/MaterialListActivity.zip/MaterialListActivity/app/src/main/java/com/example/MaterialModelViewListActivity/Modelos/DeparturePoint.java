package com.example.MaterialModelViewListActivity.Modelos;

import java.util.ArrayList;
import java.util.List;

public class DeparturePoint {
    String ciudad;
    String hora;


    public DeparturePoint(String ciudad, String hora){
        this.ciudad = ciudad;
        this.hora = hora;
    }

    public String getCiudad() {
        return  this.ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad=ciudad;
    }

    public String getHora() {
        return  this.hora;
    }

    public void setHora(String hora) {
        this.hora=hora;
    }


    @Override
    public String toString() {
        return this.getCiudad()+" "+this.getHora();
    }
}
