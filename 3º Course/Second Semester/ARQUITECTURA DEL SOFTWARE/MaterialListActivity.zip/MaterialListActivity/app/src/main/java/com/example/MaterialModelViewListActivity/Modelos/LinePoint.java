package com.example.MaterialModelViewListActivity.Modelos;

import java.util.ArrayList;
import java.util.List;

public class LinePoint {
    String origin;
    String destination;

    private List<StationPoint> stationPointList = new ArrayList<>();


    public LinePoint(String origin, String destination){
        this.origin = origin;
        this.destination = destination;
    }

    public String getOrigin() {
        return  this.origin;
    }

    public void setOrigin(String origin) {
        this.origin=origin;
    }

    public String getDestination() {
        return  this.destination;
    }

    public void setDestination(String destination) {
        this.destination=destination;
    }

    public void addStation(StationPoint stationPoint) {
        stationPointList.add(stationPoint);
    }

    public List<StationPoint> getStationPoints() {
        return this.stationPointList;
    }

    @Override
    public String toString() {
        return this.getOrigin()+" "+this.getDestination();
    }
}
