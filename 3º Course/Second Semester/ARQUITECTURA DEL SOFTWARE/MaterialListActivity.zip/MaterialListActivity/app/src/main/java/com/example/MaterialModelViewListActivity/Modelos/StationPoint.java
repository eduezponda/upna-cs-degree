package com.example.MaterialModelViewListActivity.Modelos;

import java.util.ArrayList;
import java.util.List;

public class StationPoint {
    String name;
    int position;

    private List<DeparturePoint> departurePointList = new ArrayList<>();

    public StationPoint(String name, int position){
        this.name = name;
        this.position = position;
    }

    public String getName() {
        return  this.name;
    }

    public void setName(String name) {
        this.name=name;
    }

    public int getPosition() {
        return  this.position;
    }

    public void setPosition(int position) {
        this.position=position;
    }

    public void addDeparture(DeparturePoint departurePoint) {
        departurePointList.add(departurePoint);
    }

    public List<DeparturePoint> getDeparturePointList() {
        return this.departurePointList;
    }


    @Override
    public String toString() {
        return "Estacion" + this.getPosition()+" "+ this.getName();
    }
}
