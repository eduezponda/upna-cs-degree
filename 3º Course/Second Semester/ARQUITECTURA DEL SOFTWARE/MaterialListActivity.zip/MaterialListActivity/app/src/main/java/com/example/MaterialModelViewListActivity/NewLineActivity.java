package com.example.MaterialModelViewListActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class NewLineActivity extends AppCompatActivity {

    private EditText editTextOrigen;
    private EditText editTextDestino;
    private Button buttonGuardar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_line);

        editTextOrigen = findViewById(R.id.edit_text_origen);
        editTextDestino = findViewById(R.id.edit_text_destino);
        buttonGuardar = findViewById(R.id.button_guardar);
        buttonGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String origen = editTextOrigen.getText().toString();
                String destino = editTextDestino.getText().toString();

                Intent intent = new Intent();
                intent.putExtra("origen", origen);
                intent.putExtra("destino", destino);
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }
}