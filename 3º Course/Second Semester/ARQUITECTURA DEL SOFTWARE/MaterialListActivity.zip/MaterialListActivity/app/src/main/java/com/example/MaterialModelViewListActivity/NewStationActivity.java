package com.example.MaterialModelViewListActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class NewStationActivity extends AppCompatActivity {

    private EditText editTextStation;
    private EditText editTextDistance;
    private Button buttonGuardar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_station);

        editTextStation = findViewById(R.id.edit_text_station);
        editTextDistance = findViewById(R.id.edit_text_distancia);
        buttonGuardar = findViewById(R.id.button_guardar);
        buttonGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String station = editTextStation.getText().toString();
                String distancia = editTextDistance.getText().toString();

                Intent intent = new Intent();
                intent.putExtra("station", station);
                intent.putExtra("distancia", distancia);
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }
}