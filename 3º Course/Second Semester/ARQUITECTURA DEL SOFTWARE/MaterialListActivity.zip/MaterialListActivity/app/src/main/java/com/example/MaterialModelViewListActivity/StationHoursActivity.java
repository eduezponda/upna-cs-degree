package com.example.MaterialModelViewListActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class StationHoursActivity extends AppCompatActivity {

    private ListView listView;
    private ArrayAdapter<String> puntoAdapter;
    private TravelPointApplication app;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_station_hours);
    }
}