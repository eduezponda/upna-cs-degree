package com.example.MaterialModelViewListActivity;

import android.app.Application;

import com.example.MaterialModelViewListActivity.Modelos.DeparturePoint;
import com.example.MaterialModelViewListActivity.Modelos.LinePoint;
import com.example.MaterialModelViewListActivity.Modelos.StationPoint;

import java.util.ArrayList;
import java.util.List;

public class TravelPointApplication extends Application {


    private List<LinePoint> pointList = new ArrayList<>();

    @Override
    public void onCreate() {
        super.onCreate();
    }

    public  List<LinePoint> getPointList()
    {
        return pointList;

    }

    public LinePoint getPoint(int position)
    {
        return pointList.get(position);

    }
    public  void addPoint(LinePoint aInterestPoint)
    {
        pointList.add(aInterestPoint);

    }

    public void initializeList() {

        pointList.clear();
        LinePoint aInterestPoint;
        int linesSize = 2;

        String[] origins = new String[linesSize];
        origins[0] = "Pamplona";
        origins[1] = "Pamplona";

        String[] destinations = new String[linesSize];
        destinations[0] = "Barcelona";
        destinations[1] = "Madrid";

        StationPoint stationPoint1 = new StationPoint("Pamplona", 1);
        StationPoint stationPoint2 = new StationPoint("Tafalla", 2);
        StationPoint stationPoint3 = new StationPoint("Castejon", 3);

        stationPoint1.addDeparture(new DeparturePoint("Barcelona", "12:10"));
        stationPoint1.addDeparture(new DeparturePoint("Madrid", "14:20"));
        stationPoint1.addDeparture(new DeparturePoint("Barcelona", "17:20"));

        for(int i=0; i<linesSize; i++){
            if (destinations[i] == "Madrid"){
                aInterestPoint = new LinePoint(origins[i], destinations[i]);
                aInterestPoint.addStation(stationPoint1);
                aInterestPoint.addStation(stationPoint2);
                aInterestPoint.addStation(stationPoint3);
                addPoint(aInterestPoint);
            }
            else{
                aInterestPoint = new LinePoint(origins[i], destinations[i]);
                addPoint(aInterestPoint);
            }


        }
    }




}

