package com.example.p1mainsubactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class DisplayActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display2);
    }

    public void irVentana2(View view)
    {
        Intent intent = new Intent(getApplicationContext(), DisplayActivity.class);
        startActivityForResult(intent, 1);
    }
}