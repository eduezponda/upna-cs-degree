package com.example.P3ModelViewListSubActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.example.P3ModelViewListSubActivity.Modelos.InterestPoint;

public class DisplayActivity extends AppCompatActivity {
    private int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        position = bundle.getInt("position");
        String name = bundle.getString("name");
        TextView textView =((TextView) findViewById(R.id.textViewDisplay));
        textView.setTextSize(40);
        textView.setText(name);
    }

    public void savePoint(View view) {
        Bundle bundle = new Bundle();
        EditText editName = (EditText) findViewById(R.id.edit_name);
        EditText editLatitude = (EditText) findViewById(R.id.edit_latitude);
        EditText editLongitude = (EditText) findViewById(R.id.edit_longitude);
        String name = editName.getText().toString();
        double latitude = Double.parseDouble(editLatitude.getText().toString());
        double longitude = Double.parseDouble(editLongitude.getText().toString());
        bundle.putString("name", name);
        bundle.putDouble("latitude", latitude);
        bundle.putDouble("longitude", longitude);
        bundle.putInt("position", position);
        Intent intent = new Intent();
        intent.putExtras(bundle);
        setResult(RESULT_OK, intent);
        finish();
    }
}