package com.example.P3ModelViewListSubActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.P3ModelViewListSubActivity.Modelos.InterestPoint;


public class MainListActivity extends Activity {

    private static final int SHOW_SUBACTIVITY = 1;
    ListView listView;
    ArrayAdapter<InterestPoint> interestPointsAdapter;
    TravelPointsApplication tpa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = (ListView) findViewById(R.id.list);
        tpa = (TravelPointsApplication)getApplicationContext();
        interestPointsAdapter = new ArrayAdapter<InterestPoint>(this, R.layout.row_layout, R.id.listText, tpa.getPoints());
        listView.setAdapter(interestPointsAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Bundle bundle = new Bundle();
                bundle.putInt("position", position);
                bundle.putString("name", tpa.getPointByIndex(position).getNombre());
                Intent intent = new Intent(getApplicationContext(), DisplayActivity.class);
                intent.putExtras(bundle);
                startActivityForResult(intent, SHOW_SUBACTIVITY);
            }
        });
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != Activity.RESULT_OK)
            return;
        Bundle bundle = data.getExtras();
        String name = bundle.getString("name");
        double latitude = bundle.getDouble("latitude");
        double longitude = bundle.getDouble("longitude");
        int position = bundle.getInt("position");
        InterestPoint point = tpa.getPointByIndex(position);
        point.setNombre(name);
        point.setLatitud(latitude);
        point.setLongitud(longitude);
        interestPointsAdapter.notifyDataSetChanged();
    }
}
