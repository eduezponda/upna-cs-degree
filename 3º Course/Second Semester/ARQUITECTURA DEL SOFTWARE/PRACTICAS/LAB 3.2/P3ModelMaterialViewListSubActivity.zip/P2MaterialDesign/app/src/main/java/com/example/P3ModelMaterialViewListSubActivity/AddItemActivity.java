package com.example.P3ModelMaterialViewListSubActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class AddItemActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
    }

    public void savePoint(View view) {
        Bundle bundle = new Bundle();
        EditText editName = (EditText) findViewById(R.id.edit_name);
        EditText editLatitude = (EditText) findViewById(R.id.edit_latitude);
        EditText editLongitude = (EditText) findViewById(R.id.edit_longitude);
        String name = editName.getText().toString();
        double latitude = Double.parseDouble(editLatitude.getText().toString());
        double longitude = Double.parseDouble(editLongitude.getText().toString());
        bundle.putString("name", name);
        bundle.putDouble("latitude", latitude);
        bundle.putDouble("longitude", longitude);
        Intent intent = new Intent();
        intent.putExtras(bundle);
        setResult(RESULT_OK, intent);
        finish();
    }
}