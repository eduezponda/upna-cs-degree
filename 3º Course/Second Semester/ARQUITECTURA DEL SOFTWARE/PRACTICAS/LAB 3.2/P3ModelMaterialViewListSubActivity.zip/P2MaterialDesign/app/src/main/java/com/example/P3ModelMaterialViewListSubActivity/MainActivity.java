package com.example.P3ModelMaterialViewListSubActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.example.P3ModelMaterialViewListSubActivity.Models.InterestPoint;
import com.example.P3ModelMaterialViewListSubActivity.databinding.ActivityMainBinding;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    private static final int SUBACTIVITY_ADD = 0;
    private static final int SUBACTIVITY_MODIFY = 1;

    private ActivityMainBinding binding;
    ListView listView;
    ArrayAdapter<InterestPoint> interestPointsAdapter;
    TravelPointsApplication tpa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);
        listView = (ListView)findViewById(R.id.list);
        tpa = (TravelPointsApplication)getApplicationContext();
        interestPointsAdapter = new ArrayAdapter<InterestPoint>(this, R.layout.row_layout, R.id.listText, tpa.getPoints());
        listView.setAdapter(interestPointsAdapter);

        //Botón flotante
        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle bundle = new Bundle();
                Intent intent = new Intent(getApplicationContext(), AddItemActivity.class);
                intent.putExtras(bundle);
                startActivityForResult(intent, SUBACTIVITY_ADD);
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Bundle bundle = new Bundle();
                bundle.putInt("position", position);
                bundle.putString("name", tpa.getPointByIndex(position).getName());
                Intent intent = new Intent(getApplicationContext(), ModifyActivity.class);
                intent.putExtras(bundle);
                startActivityForResult(intent, SUBACTIVITY_MODIFY);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != Activity.RESULT_OK)
            return;
        Bundle bundle = data.getExtras();
        String name = bundle.getString("name");
        double latitude = bundle.getDouble("latitude");
        double longitude = bundle.getDouble("longitude");
        InterestPoint point;
        if (requestCode == SUBACTIVITY_ADD) {
            point = new InterestPoint();
            tpa.addPoint(point);
        } else {
            int position = bundle.getInt("position");
            point = tpa.getPointByIndex(position);
        }
        point.setName(name);
        point.setLatitude(latitude);
        point.setLongitude(longitude);
        interestPointsAdapter.notifyDataSetChanged();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_reload) {
            tpa.clear();
        } else if (id == R.id.action_new) {
            Bundle bundle = new Bundle();
            Intent intent = new Intent(getApplicationContext(), AddItemActivity.class);
            intent.putExtras(bundle);
            startActivityForResult(intent, SUBACTIVITY_ADD);
        }
        interestPointsAdapter.notifyDataSetChanged();
        return super.onOptionsItemSelected(item);
    }
}