package com.example.P3ModelMaterialViewListSubActivity.Models;

public class InterestPoint {

    String name;
    double latitude;
    double longitude;

    public InterestPoint(){
    }

    public double getLatitude() {
        return  this.latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return this.longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return this.getName()+" "+this.getLatitude()+" "+this.getLongitude();
    }
}
