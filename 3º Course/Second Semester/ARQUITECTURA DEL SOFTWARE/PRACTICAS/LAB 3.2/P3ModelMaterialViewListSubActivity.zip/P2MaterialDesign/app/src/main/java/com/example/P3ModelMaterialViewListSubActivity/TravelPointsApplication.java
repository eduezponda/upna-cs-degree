package com.example.P3ModelMaterialViewListSubActivity;

import android.app.Application;

import com.example.P3ModelMaterialViewListSubActivity.Models.InterestPoint;

import java.util.ArrayList;
import java.util.List;

public class
TravelPointsApplication extends Application {

    private List<InterestPoint> pointList = new ArrayList<>();

    @Override
    public void onCreate() {
        super.onCreate();
        initializeList();
    }

    public List<InterestPoint> getPoints() {
        return pointList;
    }

    public InterestPoint getPointByIndex(int i) {
        return pointList.get(i);
    }

    public void addPoint(InterestPoint point) {
        pointList.add(point);
    }

    public void clear() {
        pointList.clear();
    }

    public void initializeList() {

        InterestPoint aInterestPoint;
        Double latitud = 43.34343;
        Double longitud = 2.34343;

        for(int i=0; i<5; i++){
            aInterestPoint = new InterestPoint();
            aInterestPoint.setName("mismo nombre");
            aInterestPoint.setLatitude(latitud+i);
            aInterestPoint.setLongitude(longitud+i);
            pointList.add(i,aInterestPoint);

        }
    }
}
