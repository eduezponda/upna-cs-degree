package com.example.back4appmvcsubactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class AddCommentActivity extends AppCompatActivity {
    private static int RESULT_COMMENT = 9;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_comment);
    }

    public void save(View view) {
        Bundle bundle = new Bundle();
        EditText editComment = (EditText) findViewById(R.id.edit_comment);

        String comment = editComment.getText().toString();

        bundle.putString("comment", comment);
        Intent intent = new Intent();
        intent.putExtras(bundle);
        setResult(RESULT_COMMENT, intent);
        finish();
    }
}