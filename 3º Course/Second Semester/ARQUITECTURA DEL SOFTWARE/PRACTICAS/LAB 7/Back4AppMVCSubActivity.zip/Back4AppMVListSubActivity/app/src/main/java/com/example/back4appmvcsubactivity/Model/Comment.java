package com.example.back4appmvcsubactivity.Model;

import com.parse.ParseClassName;
import com.parse.ParseObject;

@ParseClassName("Comment")
public class Comment extends ParseObject{

    public Comment() {
    }


    public String getComment() {return getString("comment");
    }

    public void setComment(String comment) {
        put("comment",comment);
    }

    @Override
    public String toString() {
        return this.getComment();
    }
}
