<?php
    include 'index.php';
    escribirTabla(5,"mazapan");
    escribirTabla(2, "turron");
?>