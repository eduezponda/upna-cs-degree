<?php
    // Leer el contenido del archivo HTML
$html_original = file_get_contents("ejercicio10.html"); // Reemplaza "tu_archivo.html" con la ruta de tu archivo

//$trozos = explode("##imagen##", $html_original);


$cuerpo = "";
for($i=0;$i<4;$i++){
    if($i%2==0){
        $cuerpo .= "<img src='santiago.jpg' alt='' weight = '200' height = '200'>";
    }
    else{
        $cuerpo .= "<img src='https://www.clubdeportivosancernin.es/uploads/equipos/680/190213_DSC_2390J_92c55978fb.jpg' alt='' weight = '200' height = '200'>";
    }
}

$codigoImagenes = str_replace("##imagen##", $cuerpo, $html_original);
echo $codigoImagenes;

//echo $trozos[0] . $cuerpo . $trozos[2];


?>