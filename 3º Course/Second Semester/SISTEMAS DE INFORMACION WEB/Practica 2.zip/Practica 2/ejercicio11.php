<?php
    //acceder a ejercicio11.php?numero_filas=2
    $html_original = file_get_contents("ejercicio11.html");
    if(isset($_GET['numero_filas'])) {
        $numero_filas = intval($_GET['numero_filas']);
        $cuerpo = "<table border='1'>";
        for ($i = 1; $i <= $numero_filas; $i++) {
            $cuerpo .= "<tr>";
            $cuerpo .= "<td>Hola mundo!!!!</td>";
            $cuerpo .= "<td>$i</td>";
            $cuerpo .= "</tr>";
        }
        $cuerpo .= "</table>";
        $html_original = str_replace("##cuerpo##", $cuerpo, $html_original);
    } else {
        echo "Falta el parámetro 'numero_filas' en la URL.";
    }
    echo $html_original;
?>
