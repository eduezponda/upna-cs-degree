<?php
    //acceder a ejercicio11.php?numero_filas=2
    $html_original = file_get_contents("ejercicio11.html");
    if(isset($_GET['numero_filas']) and isset($_GET['texto']) and isset($_GET['color_1']) and isset($_GET['color_2'])) {
        $numero_filas = intval($_GET['numero_filas']);
        $texto = strval($_GET['texto']);
        $color_1 = strval($_GET['color_1']);
        $color_2 = strval($_GET['color_2']);
        $array = ['red','green','blue','brown','grey','yellow'];
        if (!in_array($color_1,$array)){
            $color_1='orange';
        }
        if (!in_array($color_2,$array)){
            $color_2='white';
        }

        $cuerpo = "<table border='1'>";
        for ($i = 1; $i <= $numero_filas; $i++) {
            if ($i % 2 == 0){
                $cuerpo .= "<tr bgcolor=$color_1>";
            }
            else{
                $cuerpo .= "<tr bgcolor=$color_2>";
            }
            $cuerpo .= "<td>$texto</td>";
            $cuerpo .= "<td>$i</td>";
            $cuerpo .= "</tr>";
        }
        $cuerpo .= "</table>";
        $html_original = str_replace("##cuerpo##", $cuerpo, $html_original);
    } else {
        echo "Falta parámetros en la URL.";
    }
    echo $html_original;
?>
