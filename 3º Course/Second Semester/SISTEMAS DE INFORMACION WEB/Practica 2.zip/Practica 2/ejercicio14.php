<?php
    $html_original = file_get_contents("ejercicio11.html");
    $cuerpo = "";
    $cuerpo = "<table border='1'>";
    $nombre = strval($_GET['nombre']);
    $apellido = strval($_GET['apellido']);
    $direccion = strval($_GET['direccion']);
    $telefono = strval($_GET['telefono']);
    $email = strval($_GET['email']);

    $array = [$nombre,$apellido,$direccion,$telefono,$email];
    for ($i=0; $i<count($array);$i++){
        $cuerpo .= "<tr>";
        $cuerpo .= "<td>$array[$i]</td>";
        $cuerpo .= "</tr>";
    }
    $cuerpo .= "</table>";

    $html_original = str_replace("##cuerpo##", $cuerpo, $html_original);
    echo $html_original;

?>