<?php
    $html_original = file_get_contents("ejercicio11.html");
    $cuerpo = "";
    $cuerpo = "<table border='1'>";
    $nombre = strval($_GET['nombre']);
    $apellido = strval($_GET['apellido']);
    $direccion = strval($_GET['direccion']);
    $telefono = strval($_GET['telefono']);
    $email = strval($_GET['email']);
    $iteraciones = intval($_GET['iteraciones']);

    $array = [$nombre,$apellido,$direccion,$telefono,$email];
    for ($j=0;$j<$iteraciones;$j++){
        for ($i=0; $i<count($array);$i++){
            $cuerpo .= "<tr>";
            $cuerpo .= "<td>$array[$i]</td>";
            $cuerpo .= "</tr>";
        }
    }
    $html_original = str_replace("##cuerpo##", $cuerpo, $html_original);
    echo $html_original;

?>