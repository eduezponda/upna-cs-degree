<?php
    $html_original = file_get_contents("ejercicio11.html");
    $cuerpo = "";
    $cuerpo = "<table border='1'>";
    $nombre = strval($_GET['nombre']);
    $apellido = strval($_GET['apellido']);
    $direccion = strval($_GET['direccion']);
    $telefono = strval($_GET['telefono']);
    $email = strval($_GET['email']);

    $nombre2 = strval($_GET['nombre2']);
    $apellido2 = strval($_GET['apellido2']);
    $direccion2 = strval($_GET['direccion2']);
    $telefono2 = strval($_GET['telefono2']);
    $email2 = strval($_GET['email2']);
    $iteraciones = intval($_GET['iteraciones']);

    $array1 = [$nombre,$apellido,$direccion,$telefono,$email];
    $array2 = [$nombre2,$apellido2,$direccion2,$telefono2,$email2];
    $array = [];
    for ($j=0;$j<$iteraciones;$j++){
        if($j%2==0){
            $array = $array1;
        }
        else{
            $array = $array2;
        }
        for ($i=0; $i<count($array);$i++){

            $cuerpo .= "<tr>";
            $cuerpo .= "<td>$array[$i]</td>";
            $cuerpo .= "</tr>";
        }
    }
    $html_original = str_replace("##cuerpo##", $cuerpo, $html_original);
    echo $html_original;

?>