<?php
$datos = array(
    "nombre" => isset($_POST["nombre"]) ? $_POST["nombre"] : "",
    "apellido" => isset($_POST["apellido"]) ? $_POST["apellido"] : "",
    "direccion" => isset($_POST["direccion"]) ? $_POST["direccion"] : "",
    "telefono" => isset($_POST["telefono"]) ? $_POST["telefono"] : "",
    "email" => isset($_POST["email"]) ? $_POST["email"] : ""
);
//tiene que estar creado el archivo previamente y con permisos para escribir en propietarios públicos
$nombreArchivo = 'personas.data';
$datoscodificados = json_encode($datos);

$archivo = fopen($nombreArchivo, 'a');
file_put_contents($nombreArchivo, $datoscodificados . "\n", FILE_APPEND);
fclose($archivo);
header('Location: ejercicio18.html');

?>
