<?php
    $html_original = file_get_contents("ejercicio11.html");
    //para leer el fichero de firmas
	$firmas = "personas.data";
	$firmaslineas = file($firmas);
	foreach($firmaslineas as $persona)
	{     
        $firmas_array[] = json_decode($persona);    
    }
    $cuerpo = "";
    $cuerpo = "<table border='1'>";
    $datos=['nombre','apellido','direccion','telefono','email'];
    foreach($firmas_array as $firma){
        $cuerpo .= "<tr>";
        for ($j=0; $j<count($datos);$j++){
            $cuerpo .= "<td>" . $firma->{$datos[$j]} . "</td>";
        }
        $cuerpo .= "</tr>";  
    }
    $cuerpo .= "</table>";

    $html_original = str_replace("##cuerpo##", $cuerpo, $html_original);
    echo $html_original;

?>