<?php
    function sumar($numero1, $numero2) {
        return $numero1 + $numero2;
    }
    function escribirTabla($numeroFilas, $frase){
        echo "<table border='1'>";
        for($i=0; $i <$numeroFilas; $i++){
            echo "<tr> <td>".$frase;
            echo "</td></tr>";
        }
    echo "</table>";
    }

    echo "<!DOCTYPE html>
    <html lang=\"es\">
    <head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <title>Mi página web generada con PHP</title>
    </head>
    <body>";
    for($i=0;$i <= 9; $i++){   
        if ($i % 2 == 0){
            echo "Hola mundo! <br>";
        }
        else{
            echo "Bienvenidos al php! <br>";
        }
    }
    echo "<table border='1'>";
                $sumaFilas = 0;
                for($i=0; $i <50; $i++){
                    if ($i % 2 == 0){
                        echo "<tr bgcolor='blue'>
                        <td>" .$i;
                    }
                    else{
                        echo "<tr bgcolor='brown'>
                        <td>" .$i;
                    }
                    $sumaFilas = $sumaFilas + $i + 1;
                    echo "</td>
                    <td>" .$sumaFilas; echo "</td>
                    <td>Ejercicio número 3</td>
                    </tr>";
                }
     echo "</table>";
     $tabla = range(1, 20);
     echo "<ol>";
     foreach($tabla as $valor){
        echo "<li> Numero: " .$valor;
        echo "</li>";
     }
     echo "</ol>";

     $tabla2 = range(20, 40);
     echo "<ol>";
     for($i=0; $i<count($tabla);$i++){
        echo "<li> Numero: " .sumar($tabla[$i],$tabla2[$i]);
        echo "</li>";
     }
     echo "</ol>";
     escribirTabla(10, "mazapan");
     

     echo"</body>
     </html>";
?>

